﻿namespace SchoolDataBaseManagementsln
{
    partial class AccountDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AccountDashBoard));
            this.btnaccountdashboardpayment = new System.Windows.Forms.Button();
            this.btnaccountdashboardenroll = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnaccountdashboardlogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnaccountdashboardpayment
            // 
            this.btnaccountdashboardpayment.Location = new System.Drawing.Point(372, 142);
            this.btnaccountdashboardpayment.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnaccountdashboardpayment.Name = "btnaccountdashboardpayment";
            this.btnaccountdashboardpayment.Size = new System.Drawing.Size(80, 30);
            this.btnaccountdashboardpayment.TabIndex = 0;
            this.btnaccountdashboardpayment.Text = "Payment";
            this.btnaccountdashboardpayment.UseVisualStyleBackColor = true;
            this.btnaccountdashboardpayment.Click += new System.EventHandler(this.btnaccountdashboardpayment_Click);
            // 
            // btnaccountdashboardenroll
            // 
            this.btnaccountdashboardenroll.Location = new System.Drawing.Point(372, 220);
            this.btnaccountdashboardenroll.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnaccountdashboardenroll.Name = "btnaccountdashboardenroll";
            this.btnaccountdashboardenroll.Size = new System.Drawing.Size(80, 30);
            this.btnaccountdashboardenroll.TabIndex = 1;
            this.btnaccountdashboardenroll.Text = "Enroll";
            this.btnaccountdashboardenroll.UseVisualStyleBackColor = true;
            this.btnaccountdashboardenroll.Click += new System.EventHandler(this.btnaccountdashboardenroll_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(345, 54);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Dash Board";
            // 
            // btnaccountdashboardlogout
            // 
            this.btnaccountdashboardlogout.Location = new System.Drawing.Point(794, 62);
            this.btnaccountdashboardlogout.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnaccountdashboardlogout.Name = "btnaccountdashboardlogout";
            this.btnaccountdashboardlogout.Size = new System.Drawing.Size(80, 30);
            this.btnaccountdashboardlogout.TabIndex = 3;
            this.btnaccountdashboardlogout.Text = "Logout";
            this.btnaccountdashboardlogout.UseVisualStyleBackColor = true;
            this.btnaccountdashboardlogout.Click += new System.EventHandler(this.btnaccountdashboardlogout_Click);
            // 
            // AccountDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.btnaccountdashboardlogout);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnaccountdashboardenroll);
            this.Controls.Add(this.btnaccountdashboardpayment);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "AccountDashBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AccountDashBoard";
            this.Load += new System.EventHandler(this.AccountDashBoard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnaccountdashboardpayment;
        private Button btnaccountdashboardenroll;
        private Label label1;
        private Button btnaccountdashboardlogout;
    }
}