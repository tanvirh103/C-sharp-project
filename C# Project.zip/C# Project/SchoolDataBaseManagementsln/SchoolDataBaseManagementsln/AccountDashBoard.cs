﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class AccountDashBoard : Form
    {
        public AccountDashBoard()
        {
            InitializeComponent();
        }

        private void btnaccountdashboardpayment_Click(object sender, EventArgs e)
        {
            PaymentDashBoard pdb = new PaymentDashBoard();
            this.Close();
            pdb.Show();
        }

        private void btnaccountdashboardenroll_Click(object sender, EventArgs e)
        {
           EnrollStudent es=new EnrollStudent();
            this.Hide();
            es.Show();
        }

        private void AccountDashBoard_Load(object sender, EventArgs e)
        {
            
        }

        private void btnaccountdashboardlogout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Close();
            lg.Show();
        }
    }
}
