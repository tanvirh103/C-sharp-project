﻿namespace SchoolDataBaseManagementsln
{
    partial class AdminDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashBoard));
            this.btnStudentinfo = new System.Windows.Forms.Button();
            this.btnteacherinfo = new System.Windows.Forms.Button();
            this.btnstaffinfo = new System.Windows.Forms.Button();
            this.lbladmindashboardmanage = new System.Windows.Forms.Label();
            this.btndashboardsubject = new System.Windows.Forms.Button();
            this.btncategoryresult = new System.Windows.Forms.Button();
            this.btnadmindashclass = new System.Windows.Forms.Button();
            this.btnadmindashboardlogout = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStudentinfo
            // 
            this.btnStudentinfo.BackColor = System.Drawing.Color.Transparent;
            this.btnStudentinfo.Location = new System.Drawing.Point(147, 110);
            this.btnStudentinfo.Margin = new System.Windows.Forms.Padding(2);
            this.btnStudentinfo.Name = "btnStudentinfo";
            this.btnStudentinfo.Size = new System.Drawing.Size(80, 30);
            this.btnStudentinfo.TabIndex = 0;
            this.btnStudentinfo.Text = "Student";
            this.btnStudentinfo.UseVisualStyleBackColor = false;
            this.btnStudentinfo.Click += new System.EventHandler(this.btnStudentinfo_Click);
            // 
            // btnteacherinfo
            // 
            this.btnteacherinfo.BackColor = System.Drawing.Color.Transparent;
            this.btnteacherinfo.Location = new System.Drawing.Point(147, 158);
            this.btnteacherinfo.Margin = new System.Windows.Forms.Padding(2);
            this.btnteacherinfo.Name = "btnteacherinfo";
            this.btnteacherinfo.Size = new System.Drawing.Size(80, 30);
            this.btnteacherinfo.TabIndex = 1;
            this.btnteacherinfo.Text = "Teacher";
            this.btnteacherinfo.UseVisualStyleBackColor = false;
            this.btnteacherinfo.Click += new System.EventHandler(this.btnteacherinfo_Click);
            // 
            // btnstaffinfo
            // 
            this.btnstaffinfo.BackColor = System.Drawing.Color.Transparent;
            this.btnstaffinfo.Location = new System.Drawing.Point(147, 209);
            this.btnstaffinfo.Margin = new System.Windows.Forms.Padding(2);
            this.btnstaffinfo.Name = "btnstaffinfo";
            this.btnstaffinfo.Size = new System.Drawing.Size(80, 30);
            this.btnstaffinfo.TabIndex = 2;
            this.btnstaffinfo.Text = "Staff";
            this.btnstaffinfo.UseVisualStyleBackColor = false;
            this.btnstaffinfo.Click += new System.EventHandler(this.btnstaffinfo_Click);
            // 
            // lbladmindashboardmanage
            // 
            this.lbladmindashboardmanage.AutoSize = true;
            this.lbladmindashboardmanage.BackColor = System.Drawing.Color.Transparent;
            this.lbladmindashboardmanage.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbladmindashboardmanage.Location = new System.Drawing.Point(93, 50);
            this.lbladmindashboardmanage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbladmindashboardmanage.Name = "lbladmindashboardmanage";
            this.lbladmindashboardmanage.Size = new System.Drawing.Size(210, 32);
            this.lbladmindashboardmanage.TabIndex = 3;
            this.lbladmindashboardmanage.Text = "Manage my school";
            // 
            // btndashboardsubject
            // 
            this.btndashboardsubject.BackColor = System.Drawing.Color.Transparent;
            this.btndashboardsubject.Location = new System.Drawing.Point(147, 256);
            this.btndashboardsubject.Margin = new System.Windows.Forms.Padding(2);
            this.btndashboardsubject.Name = "btndashboardsubject";
            this.btndashboardsubject.Size = new System.Drawing.Size(80, 30);
            this.btndashboardsubject.TabIndex = 4;
            this.btndashboardsubject.Text = "Subject";
            this.btndashboardsubject.UseVisualStyleBackColor = false;
            this.btndashboardsubject.Click += new System.EventHandler(this.btndashboardsubject_Click);
            // 
            // btncategoryresult
            // 
            this.btncategoryresult.BackColor = System.Drawing.Color.Transparent;
            this.btncategoryresult.Location = new System.Drawing.Point(147, 311);
            this.btncategoryresult.Margin = new System.Windows.Forms.Padding(2);
            this.btncategoryresult.Name = "btncategoryresult";
            this.btncategoryresult.Size = new System.Drawing.Size(80, 30);
            this.btncategoryresult.TabIndex = 5;
            this.btncategoryresult.Text = "Result";
            this.btncategoryresult.UseVisualStyleBackColor = false;
            this.btncategoryresult.Click += new System.EventHandler(this.btncategoryresult_Click);
            // 
            // btnadmindashclass
            // 
            this.btnadmindashclass.BackColor = System.Drawing.Color.Transparent;
            this.btnadmindashclass.Location = new System.Drawing.Point(147, 359);
            this.btnadmindashclass.Margin = new System.Windows.Forms.Padding(2);
            this.btnadmindashclass.Name = "btnadmindashclass";
            this.btnadmindashclass.Size = new System.Drawing.Size(80, 30);
            this.btnadmindashclass.TabIndex = 6;
            this.btnadmindashclass.Text = "Class";
            this.btnadmindashclass.UseVisualStyleBackColor = false;
            this.btnadmindashclass.Click += new System.EventHandler(this.btnadmindashclass_Click);
            // 
            // btnadmindashboardlogout
            // 
            this.btnadmindashboardlogout.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnadmindashboardlogout.Location = new System.Drawing.Point(792, 50);
            this.btnadmindashboardlogout.Margin = new System.Windows.Forms.Padding(2);
            this.btnadmindashboardlogout.Name = "btnadmindashboardlogout";
            this.btnadmindashboardlogout.Size = new System.Drawing.Size(80, 30);
            this.btnadmindashboardlogout.TabIndex = 7;
            this.btnadmindashboardlogout.Text = "Logout";
            this.btnadmindashboardlogout.UseVisualStyleBackColor = true;
            this.btnadmindashboardlogout.Click += new System.EventHandler(this.btnadmindashboardlogout_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(147, 412);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 30);
            this.button1.TabIndex = 8;
            this.button1.Text = "AC_REQ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AdminDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnadmindashboardlogout);
            this.Controls.Add(this.btnadmindashclass);
            this.Controls.Add(this.btncategoryresult);
            this.Controls.Add(this.btndashboardsubject);
            this.Controls.Add(this.lbladmindashboardmanage);
            this.Controls.Add(this.btnstaffinfo);
            this.Controls.Add(this.btnteacherinfo);
            this.Controls.Add(this.btnStudentinfo);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AdminDashBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminDashBoard";
            this.Load += new System.EventHandler(this.AdminDashBoard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnStudentinfo;
        private Button btnteacherinfo;
        private Button btnstaffinfo;
        private Label lbladmindashboardmanage;
        private Button btndashboardsubject;
        private Button btncategoryresult;
        private Button btnadmindashclass;
        private Button btnadmindashboardlogout;
        private Button button1;
    }
}