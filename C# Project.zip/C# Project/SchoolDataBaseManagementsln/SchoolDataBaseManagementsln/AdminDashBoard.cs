﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class AdminDashBoard : Form
    {
        public AdminDashBoard()
        {
            InitializeComponent();
        }

        private void btnStudentinfo_Click(object sender, EventArgs e)
        {
            DashBoardStudent ds= new DashBoardStudent();
            this.Hide();
            ds.Show();
        }

        private void btnteacherinfo_Click(object sender, EventArgs e)
        {
            DashBoardTeacher dteacher= new DashBoardTeacher();
            this.Hide();        
            dteacher.Show();
        }

        private void btnstaffinfo_Click(object sender, EventArgs e)
        {
            DashBoardStaff dstaff= new DashBoardStaff();
            this.Hide();
            dstaff.Show();
        }

        private void btndashboardsubject_Click(object sender, EventArgs e)
        {
            SubjectDash subdash=new SubjectDash();
            this.Hide();
            subdash.Show();
        }

        private void btncategoryresult_Click(object sender, EventArgs e)
        {
            ResultDash rd=new ResultDash();
            this.Hide();
            rd.Show();
        }

        private void btnadmindashclass_Click(object sender, EventArgs e)
        {
            ClassDashBoard cdb = new ClassDashBoard();
            this.Hide();
            cdb.Show();
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void btnadmindashboardlogout_Click(object sender, EventArgs e)
        {
            Login log=new Login();
            this.Close();
            log.Show();
        }

        private void AdminDashBoard_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Request r=new Request();
            this.Close();
            r.Show();
        }
    }
}
