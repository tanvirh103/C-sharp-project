﻿namespace SchoolDataBaseManagementsln
{
    partial class ClassDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClassDashBoard));
            this.lblclassdashboardclass = new System.Windows.Forms.Label();
            this.lblclassdashboardid = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.CL_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CL_Section = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CL_STD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CL_T_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblclassdashboardsearch = new System.Windows.Forms.Label();
            this.btnclassdashboardsearch = new System.Windows.Forms.Button();
            this.btnclassdashboardload = new System.Windows.Forms.Button();
            this.btnclassdashboardinsert = new System.Windows.Forms.Button();
            this.btnclassdashboardupdate = new System.Windows.Forms.Button();
            this.btnclassdashboarddelect = new System.Windows.Forms.Button();
            this.btnclassdashboardback = new System.Windows.Forms.Button();
            this.lblclassdashboardclassid = new System.Windows.Forms.Label();
            this.lblclassdashboardassignto = new System.Windows.Forms.Label();
            this.txtclassdashboardid = new System.Windows.Forms.TextBox();
            this.txtclassdashboard = new System.Windows.Forms.TextBox();
            this.lblclassdashboardsection = new System.Windows.Forms.Label();
            this.txtclassdashboardsection = new System.Windows.Forms.TextBox();
            this.lblclassstan = new System.Windows.Forms.Label();
            this.txtclassstandard = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblclassdashboardclass
            // 
            this.lblclassdashboardclass.AutoSize = true;
            this.lblclassdashboardclass.BackColor = System.Drawing.Color.Transparent;
            this.lblclassdashboardclass.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblclassdashboardclass.Location = new System.Drawing.Point(288, 22);
            this.lblclassdashboardclass.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblclassdashboardclass.Name = "lblclassdashboardclass";
            this.lblclassdashboardclass.Size = new System.Drawing.Size(261, 32);
            this.lblclassdashboardclass.TabIndex = 0;
            this.lblclassdashboardclass.Text = "Class Room Information";
            // 
            // lblclassdashboardid
            // 
            this.lblclassdashboardid.AutoSize = true;
            this.lblclassdashboardid.BackColor = System.Drawing.Color.Transparent;
            this.lblclassdashboardid.Location = new System.Drawing.Point(507, 76);
            this.lblclassdashboardid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblclassdashboardid.Name = "lblclassdashboardid";
            this.lblclassdashboardid.Size = new System.Drawing.Size(51, 15);
            this.lblclassdashboardid.TabIndex = 1;
            this.lblclassdashboardid.Text = "Class ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CL_ID,
            this.CL_Section,
            this.CL_STD,
            this.T_Name,
            this.CL_T_ID});
            this.dataGridView1.Location = new System.Drawing.Point(8, 65);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(494, 245);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // CL_ID
            // 
            this.CL_ID.DataPropertyName = "CL_ID";
            this.CL_ID.HeaderText = "Class ID";
            this.CL_ID.MinimumWidth = 8;
            this.CL_ID.Name = "CL_ID";
            this.CL_ID.ReadOnly = true;
            this.CL_ID.Width = 150;
            // 
            // CL_Section
            // 
            this.CL_Section.DataPropertyName = "CL_Section";
            this.CL_Section.HeaderText = "Class Section";
            this.CL_Section.MinimumWidth = 8;
            this.CL_Section.Name = "CL_Section";
            this.CL_Section.ReadOnly = true;
            this.CL_Section.Width = 150;
            // 
            // CL_STD
            // 
            this.CL_STD.DataPropertyName = "CL_STD";
            this.CL_STD.HeaderText = "Standard";
            this.CL_STD.MinimumWidth = 8;
            this.CL_STD.Name = "CL_STD";
            this.CL_STD.ReadOnly = true;
            this.CL_STD.Width = 150;
            // 
            // T_Name
            // 
            this.T_Name.DataPropertyName = "T_Name";
            this.T_Name.HeaderText = "Assign Teacher";
            this.T_Name.MinimumWidth = 8;
            this.T_Name.Name = "T_Name";
            this.T_Name.ReadOnly = true;
            this.T_Name.Width = 150;
            // 
            // CL_T_ID
            // 
            this.CL_T_ID.DataPropertyName = "CL_T_ID";
            this.CL_T_ID.HeaderText = "Teacher ID";
            this.CL_T_ID.MinimumWidth = 8;
            this.CL_T_ID.Name = "CL_T_ID";
            this.CL_T_ID.ReadOnly = true;
            this.CL_T_ID.Width = 150;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(606, 73);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(166, 23);
            this.textBox1.TabIndex = 3;
            // 
            // lblclassdashboardsearch
            // 
            this.lblclassdashboardsearch.AutoSize = true;
            this.lblclassdashboardsearch.BackColor = System.Drawing.Color.Transparent;
            this.lblclassdashboardsearch.Location = new System.Drawing.Point(643, 43);
            this.lblclassdashboardsearch.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblclassdashboardsearch.Name = "lblclassdashboardsearch";
            this.lblclassdashboardsearch.Size = new System.Drawing.Size(72, 15);
            this.lblclassdashboardsearch.TabIndex = 4;
            this.lblclassdashboardsearch.Text = "Search Class";
            // 
            // btnclassdashboardsearch
            // 
            this.btnclassdashboardsearch.Location = new System.Drawing.Point(808, 73);
            this.btnclassdashboardsearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnclassdashboardsearch.Name = "btnclassdashboardsearch";
            this.btnclassdashboardsearch.Size = new System.Drawing.Size(80, 30);
            this.btnclassdashboardsearch.TabIndex = 5;
            this.btnclassdashboardsearch.Text = "Search";
            this.btnclassdashboardsearch.UseVisualStyleBackColor = true;
            this.btnclassdashboardsearch.Click += new System.EventHandler(this.btnclassdashboardsearch_Click);
            // 
            // btnclassdashboardload
            // 
            this.btnclassdashboardload.Location = new System.Drawing.Point(183, 348);
            this.btnclassdashboardload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnclassdashboardload.Name = "btnclassdashboardload";
            this.btnclassdashboardload.Size = new System.Drawing.Size(80, 30);
            this.btnclassdashboardload.TabIndex = 6;
            this.btnclassdashboardload.Text = "Load";
            this.btnclassdashboardload.UseVisualStyleBackColor = true;
            this.btnclassdashboardload.Click += new System.EventHandler(this.btnclassdashboardload_Click);
            // 
            // btnclassdashboardinsert
            // 
            this.btnclassdashboardinsert.Location = new System.Drawing.Point(542, 260);
            this.btnclassdashboardinsert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnclassdashboardinsert.Name = "btnclassdashboardinsert";
            this.btnclassdashboardinsert.Size = new System.Drawing.Size(80, 30);
            this.btnclassdashboardinsert.TabIndex = 7;
            this.btnclassdashboardinsert.Text = "Insert";
            this.btnclassdashboardinsert.UseVisualStyleBackColor = true;
            this.btnclassdashboardinsert.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnclassdashboardupdate
            // 
            this.btnclassdashboardupdate.Location = new System.Drawing.Point(643, 260);
            this.btnclassdashboardupdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnclassdashboardupdate.Name = "btnclassdashboardupdate";
            this.btnclassdashboardupdate.Size = new System.Drawing.Size(80, 30);
            this.btnclassdashboardupdate.TabIndex = 8;
            this.btnclassdashboardupdate.Text = "Update";
            this.btnclassdashboardupdate.UseVisualStyleBackColor = true;
            this.btnclassdashboardupdate.Click += new System.EventHandler(this.btnclassdashboardupdate_Click);
            // 
            // btnclassdashboarddelect
            // 
            this.btnclassdashboarddelect.Location = new System.Drawing.Point(753, 260);
            this.btnclassdashboarddelect.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnclassdashboarddelect.Name = "btnclassdashboarddelect";
            this.btnclassdashboarddelect.Size = new System.Drawing.Size(80, 30);
            this.btnclassdashboarddelect.TabIndex = 9;
            this.btnclassdashboarddelect.Text = "Delete";
            this.btnclassdashboarddelect.UseVisualStyleBackColor = true;
            this.btnclassdashboarddelect.Click += new System.EventHandler(this.btnclassdashboarddelect_Click);
            // 
            // btnclassdashboardback
            // 
            this.btnclassdashboardback.Location = new System.Drawing.Point(38, 436);
            this.btnclassdashboardback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnclassdashboardback.Name = "btnclassdashboardback";
            this.btnclassdashboardback.Size = new System.Drawing.Size(80, 30);
            this.btnclassdashboardback.TabIndex = 10;
            this.btnclassdashboardback.Text = "Back";
            this.btnclassdashboardback.UseVisualStyleBackColor = true;
            this.btnclassdashboardback.Click += new System.EventHandler(this.btnclassdashboardback_Click);
            // 
            // lblclassdashboardclassid
            // 
            this.lblclassdashboardclassid.AutoSize = true;
            this.lblclassdashboardclassid.BackColor = System.Drawing.Color.Transparent;
            this.lblclassdashboardclassid.Location = new System.Drawing.Point(507, 118);
            this.lblclassdashboardclassid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblclassdashboardclassid.Name = "lblclassdashboardclassid";
            this.lblclassdashboardclassid.Size = new System.Drawing.Size(51, 15);
            this.lblclassdashboardclassid.TabIndex = 11;
            this.lblclassdashboardclassid.Text = "Class ID:";
            // 
            // lblclassdashboardassignto
            // 
            this.lblclassdashboardassignto.AutoSize = true;
            this.lblclassdashboardassignto.BackColor = System.Drawing.Color.Transparent;
            this.lblclassdashboardassignto.Location = new System.Drawing.Point(507, 157);
            this.lblclassdashboardassignto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblclassdashboardassignto.Name = "lblclassdashboardassignto";
            this.lblclassdashboardassignto.Size = new System.Drawing.Size(64, 15);
            this.lblclassdashboardassignto.TabIndex = 12;
            this.lblclassdashboardassignto.Text = "Teacher ID:";
            // 
            // txtclassdashboardid
            // 
            this.txtclassdashboardid.Location = new System.Drawing.Point(606, 116);
            this.txtclassdashboardid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtclassdashboardid.Name = "txtclassdashboardid";
            this.txtclassdashboardid.Size = new System.Drawing.Size(166, 23);
            this.txtclassdashboardid.TabIndex = 14;
            // 
            // txtclassdashboard
            // 
            this.txtclassdashboard.Location = new System.Drawing.Point(606, 155);
            this.txtclassdashboard.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtclassdashboard.Name = "txtclassdashboard";
            this.txtclassdashboard.Size = new System.Drawing.Size(166, 23);
            this.txtclassdashboard.TabIndex = 15;
            // 
            // lblclassdashboardsection
            // 
            this.lblclassdashboardsection.AutoSize = true;
            this.lblclassdashboardsection.BackColor = System.Drawing.Color.Transparent;
            this.lblclassdashboardsection.Location = new System.Drawing.Point(507, 189);
            this.lblclassdashboardsection.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblclassdashboardsection.Name = "lblclassdashboardsection";
            this.lblclassdashboardsection.Size = new System.Drawing.Size(79, 15);
            this.lblclassdashboardsection.TabIndex = 17;
            this.lblclassdashboardsection.Text = "Class Section:";
            // 
            // txtclassdashboardsection
            // 
            this.txtclassdashboardsection.Location = new System.Drawing.Point(606, 187);
            this.txtclassdashboardsection.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtclassdashboardsection.Name = "txtclassdashboardsection";
            this.txtclassdashboardsection.Size = new System.Drawing.Size(166, 23);
            this.txtclassdashboardsection.TabIndex = 18;
            // 
            // lblclassstan
            // 
            this.lblclassstan.AutoSize = true;
            this.lblclassstan.BackColor = System.Drawing.Color.Transparent;
            this.lblclassstan.Location = new System.Drawing.Point(507, 226);
            this.lblclassstan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblclassstan.Name = "lblclassstan";
            this.lblclassstan.Size = new System.Drawing.Size(57, 15);
            this.lblclassstan.TabIndex = 19;
            this.lblclassstan.Text = "Standard:";
            // 
            // txtclassstandard
            // 
            this.txtclassstandard.Location = new System.Drawing.Point(606, 224);
            this.txtclassstandard.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtclassstandard.Name = "txtclassstandard";
            this.txtclassstandard.Size = new System.Drawing.Size(166, 23);
            this.txtclassstandard.TabIndex = 20;
            // 
            // ClassDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.txtclassstandard);
            this.Controls.Add(this.lblclassstan);
            this.Controls.Add(this.txtclassdashboardsection);
            this.Controls.Add(this.lblclassdashboardsection);
            this.Controls.Add(this.txtclassdashboard);
            this.Controls.Add(this.txtclassdashboardid);
            this.Controls.Add(this.lblclassdashboardassignto);
            this.Controls.Add(this.lblclassdashboardclassid);
            this.Controls.Add(this.btnclassdashboardback);
            this.Controls.Add(this.btnclassdashboarddelect);
            this.Controls.Add(this.btnclassdashboardupdate);
            this.Controls.Add(this.btnclassdashboardinsert);
            this.Controls.Add(this.btnclassdashboardload);
            this.Controls.Add(this.btnclassdashboardsearch);
            this.Controls.Add(this.lblclassdashboardsearch);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblclassdashboardid);
            this.Controls.Add(this.lblclassdashboardclass);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ClassDashBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ClassDashBoard";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblclassdashboardclass;
        private Label lblclassdashboardid;
        private DataGridView dataGridView1;
        private TextBox textBox1;
        private Label lblclassdashboardsearch;
        private Button btnclassdashboardsearch;
        private Button btnclassdashboardload;
        private Button btnclassdashboardinsert;
        private Button btnclassdashboardupdate;
        private Button btnclassdashboarddelect;
        private Button btnclassdashboardback;
        private Label lblclassdashboardclassid;
        private Label lblclassdashboardassignto;
        private TextBox txtclassdashboardid;
        private TextBox txtclassdashboard;
        private Label lblclassdashboardsection;
        private TextBox txtclassdashboardsection;
        private Label lblclassstan;
        private TextBox txtclassstandard;
        private DataGridViewTextBoxColumn CL_ID;
        private DataGridViewTextBoxColumn CL_Section;
        private DataGridViewTextBoxColumn CL_STD;
        private DataGridViewTextBoxColumn T_Name;
        private DataGridViewTextBoxColumn CL_T_ID;
    }
}