﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class ClassDashBoard : Form
    {
        public ClassDashBoard()
        {
            InitializeComponent();
        }
        public void primary()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select Class.CL_ID,Class.CL_Section,Class.CL_STD,Class.CL_T_ID,Teacher.T_Name from Class,Teacher Where Class.CL_T_ID=Teacher.T_ID;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO Class( CL_ID, CL_Section, CL_STD,CL_T_ID) VALUES('" + txtclassdashboardid.Text + "', '" + txtclassdashboardsection.Text + "', '" + txtclassstandard.Text + "','" + txtclassdashboard.Text + "')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();

        }

        private void btnclassdashboardback_Click(object sender, EventArgs e)
        {
            AdminDashBoard adb=new AdminDashBoard();
            this.Hide();
            adb.Show();
        }
        

        private void btnclassdashboardload_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select Class.CL_ID,Class.CL_Section,Class.CL_T_ID,Class.CL_STD,Teacher.T_Name from Class,Teacher Where Class.CL_T_ID=Teacher.T_ID;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnclassdashboardsearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from Class where CL_ID like '" + textBox1.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnclassdashboarddelect_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string qu = "delete from Class where CL_ID=" + txtclassdashboardid.Text;
            SqlCommand cmd = new SqlCommand(qu, conn);
            cmd.ExecuteNonQuery();
            primary();
            txtclassdashboardid.Text = " ";
            txtclassdashboard.Text = " ";
            txtclassdashboardsection.Text = " ";
            txtclassstandard.Text = " ";
            

        }

        private void btnclassdashboardupdate_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Class set CL_T_ID='" + txtclassdashboard.Text +"',CL_Section='"+ txtclassdashboardsection.Text+"',CL_STD='"+ txtclassstandard.Text+"'where CL_ID =" + txtclassdashboardid.Text;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            primary();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string cl_id = dataGridView1.Rows[e.RowIndex].Cells["CL_ID"].Value.ToString();
            string cl_section = dataGridView1.Rows[e.RowIndex].Cells["CL_Section"].Value.ToString();

            string teacher = dataGridView1.Rows[e.RowIndex].Cells["CL_T_ID"].Value.ToString();
            string stand = dataGridView1.Rows[e.RowIndex].Cells["CL_STD"].Value.ToString();

            txtclassdashboardid.Text = cl_id;
            txtclassdashboardsection.Text = cl_section;
            txtclassdashboard.Text = teacher;
            txtclassstandard.Text = stand;
        }
    }
}
