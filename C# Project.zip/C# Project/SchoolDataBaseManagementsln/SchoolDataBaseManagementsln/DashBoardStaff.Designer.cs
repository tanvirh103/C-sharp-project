﻿namespace SchoolDataBaseManagementsln
{
    partial class DashBoardStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoardStaff));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ST_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ST_Salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ST_Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ST_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ST_DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ST_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ST_Position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.lblstaffdepartment = new System.Windows.Forms.Label();
            this.lblstaffname = new System.Windows.Forms.Label();
            this.lblstaffid = new System.Windows.Forms.Label();
            this.lblstaffidsearch = new System.Windows.Forms.Label();
            this.txtsearchstaffid = new System.Windows.Forms.TextBox();
            this.txtstaffname = new System.Windows.Forms.TextBox();
            this.txtstaffid = new System.Windows.Forms.TextBox();
            this.btnsearchstaff = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnload = new System.Windows.Forms.Button();
            this.btninsertstaff = new System.Windows.Forms.Button();
            this.btndeletestaff = new System.Windows.Forms.Button();
            this.btnupdatestaff = new System.Windows.Forms.Button();
            this.lblstaffinfo = new System.Windows.Forms.Label();
            this.btnstaffinfoback = new System.Windows.Forms.Button();
            this.lbldashboardstaffaddress = new System.Windows.Forms.Label();
            this.txtdashboardstaffaddress = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbldashboardstaffdob = new System.Windows.Forms.Label();
            this.lbldashboardstaffpassword = new System.Windows.Forms.Label();
            this.txtdashboardstaffpassword = new System.Windows.Forms.TextBox();
            this.txtdashboardstaffphone = new System.Windows.Forms.TextBox();
            this.lbldashboardstaffphone = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ST_ID,
            this.ST_Salary,
            this.ST_Phone,
            this.ST_Name,
            this.ST_DOB,
            this.ST_Address,
            this.ST_Position});
            this.dataGridView1.Location = new System.Drawing.Point(8, 60);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(468, 230);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ST_ID
            // 
            this.ST_ID.DataPropertyName = "ST_ID";
            this.ST_ID.HeaderText = "Staff ID";
            this.ST_ID.MinimumWidth = 8;
            this.ST_ID.Name = "ST_ID";
            this.ST_ID.ReadOnly = true;
            this.ST_ID.Width = 150;
            // 
            // ST_Salary
            // 
            this.ST_Salary.DataPropertyName = "ST_Salary";
            this.ST_Salary.HeaderText = "Salary";
            this.ST_Salary.MinimumWidth = 8;
            this.ST_Salary.Name = "ST_Salary";
            this.ST_Salary.ReadOnly = true;
            this.ST_Salary.Width = 150;
            // 
            // ST_Phone
            // 
            this.ST_Phone.DataPropertyName = "ST_Phone";
            this.ST_Phone.HeaderText = "Staff Phone";
            this.ST_Phone.MinimumWidth = 8;
            this.ST_Phone.Name = "ST_Phone";
            this.ST_Phone.ReadOnly = true;
            this.ST_Phone.Width = 150;
            // 
            // ST_Name
            // 
            this.ST_Name.DataPropertyName = "ST_Name";
            this.ST_Name.HeaderText = "Staff Name";
            this.ST_Name.MinimumWidth = 8;
            this.ST_Name.Name = "ST_Name";
            this.ST_Name.ReadOnly = true;
            this.ST_Name.Width = 150;
            // 
            // ST_DOB
            // 
            this.ST_DOB.DataPropertyName = "ST_DOB";
            this.ST_DOB.HeaderText = "Staff DOB";
            this.ST_DOB.MinimumWidth = 8;
            this.ST_DOB.Name = "ST_DOB";
            this.ST_DOB.ReadOnly = true;
            this.ST_DOB.Width = 150;
            // 
            // ST_Address
            // 
            this.ST_Address.DataPropertyName = "ST_Address";
            this.ST_Address.HeaderText = "Staff Address";
            this.ST_Address.MinimumWidth = 8;
            this.ST_Address.Name = "ST_Address";
            this.ST_Address.ReadOnly = true;
            this.ST_Address.Width = 150;
            // 
            // ST_Position
            // 
            this.ST_Position.DataPropertyName = "ST_Position";
            this.ST_Position.HeaderText = "Staff Position";
            this.ST_Position.MinimumWidth = 8;
            this.ST_Position.Name = "ST_Position";
            this.ST_Position.ReadOnly = true;
            this.ST_Position.Width = 150;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(615, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Search Staff";
            // 
            // lblstaffdepartment
            // 
            this.lblstaffdepartment.AutoSize = true;
            this.lblstaffdepartment.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffdepartment.Location = new System.Drawing.Point(491, 212);
            this.lblstaffdepartment.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffdepartment.Name = "lblstaffdepartment";
            this.lblstaffdepartment.Size = new System.Drawing.Size(73, 15);
            this.lblstaffdepartment.TabIndex = 3;
            this.lblstaffdepartment.Text = "Department:";
            // 
            // lblstaffname
            // 
            this.lblstaffname.AutoSize = true;
            this.lblstaffname.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffname.Location = new System.Drawing.Point(491, 117);
            this.lblstaffname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffname.Name = "lblstaffname";
            this.lblstaffname.Size = new System.Drawing.Size(69, 15);
            this.lblstaffname.TabIndex = 4;
            this.lblstaffname.Text = "Staff Name:";
            // 
            // lblstaffid
            // 
            this.lblstaffid.AutoSize = true;
            this.lblstaffid.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffid.Location = new System.Drawing.Point(496, 81);
            this.lblstaffid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffid.Name = "lblstaffid";
            this.lblstaffid.Size = new System.Drawing.Size(51, 15);
            this.lblstaffid.TabIndex = 5;
            this.lblstaffid.Text = "Staff ID: ";
            // 
            // lblstaffidsearch
            // 
            this.lblstaffidsearch.AutoSize = true;
            this.lblstaffidsearch.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffidsearch.Location = new System.Drawing.Point(491, 42);
            this.lblstaffidsearch.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffidsearch.Name = "lblstaffidsearch";
            this.lblstaffidsearch.Size = new System.Drawing.Size(48, 15);
            this.lblstaffidsearch.TabIndex = 6;
            this.lblstaffidsearch.Text = "Staff ID:";
            // 
            // txtsearchstaffid
            // 
            this.txtsearchstaffid.Location = new System.Drawing.Point(574, 43);
            this.txtsearchstaffid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtsearchstaffid.Name = "txtsearchstaffid";
            this.txtsearchstaffid.Size = new System.Drawing.Size(211, 23);
            this.txtsearchstaffid.TabIndex = 7;
            this.txtsearchstaffid.TextChanged += new System.EventHandler(this.txtsearchstaffid_TextChanged);
            // 
            // txtstaffname
            // 
            this.txtstaffname.Location = new System.Drawing.Point(574, 115);
            this.txtstaffname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstaffname.Name = "txtstaffname";
            this.txtstaffname.Size = new System.Drawing.Size(211, 23);
            this.txtstaffname.TabIndex = 9;
            // 
            // txtstaffid
            // 
            this.txtstaffid.Location = new System.Drawing.Point(574, 77);
            this.txtstaffid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstaffid.Name = "txtstaffid";
            this.txtstaffid.ReadOnly = true;
            this.txtstaffid.Size = new System.Drawing.Size(211, 23);
            this.txtstaffid.TabIndex = 10;
            this.txtstaffid.TextChanged += new System.EventHandler(this.txtstaffid_TextChanged);
            // 
            // btnsearchstaff
            // 
            this.btnsearchstaff.Location = new System.Drawing.Point(804, 38);
            this.btnsearchstaff.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsearchstaff.Name = "btnsearchstaff";
            this.btnsearchstaff.Size = new System.Drawing.Size(80, 30);
            this.btnsearchstaff.TabIndex = 11;
            this.btnsearchstaff.Text = "Search";
            this.btnsearchstaff.UseVisualStyleBackColor = true;
            this.btnsearchstaff.Click += new System.EventHandler(this.btnsearchstaff_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cleaner",
            "Pioen",
            "Security",
            "Management"});
            this.comboBox1.Location = new System.Drawing.Point(574, 207);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(211, 23);
            this.comboBox1.TabIndex = 12;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btnload
            // 
            this.btnload.Location = new System.Drawing.Point(189, 324);
            this.btnload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(80, 30);
            this.btnload.TabIndex = 13;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = true;
            this.btnload.Click += new System.EventHandler(this.button1_Click);
            // 
            // btninsertstaff
            // 
            this.btninsertstaff.Location = new System.Drawing.Point(501, 337);
            this.btninsertstaff.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btninsertstaff.Name = "btninsertstaff";
            this.btninsertstaff.Size = new System.Drawing.Size(80, 30);
            this.btninsertstaff.TabIndex = 14;
            this.btninsertstaff.Text = "Insert";
            this.btninsertstaff.UseVisualStyleBackColor = true;
            this.btninsertstaff.Click += new System.EventHandler(this.btninsertstaff_Click);
            // 
            // btndeletestaff
            // 
            this.btndeletestaff.Location = new System.Drawing.Point(706, 337);
            this.btndeletestaff.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btndeletestaff.Name = "btndeletestaff";
            this.btndeletestaff.Size = new System.Drawing.Size(80, 30);
            this.btndeletestaff.TabIndex = 15;
            this.btndeletestaff.Text = "Delete";
            this.btndeletestaff.UseVisualStyleBackColor = true;
            this.btndeletestaff.Click += new System.EventHandler(this.btndeletestaff_Click);
            // 
            // btnupdatestaff
            // 
            this.btnupdatestaff.Location = new System.Drawing.Point(610, 337);
            this.btnupdatestaff.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnupdatestaff.Name = "btnupdatestaff";
            this.btnupdatestaff.Size = new System.Drawing.Size(80, 30);
            this.btnupdatestaff.TabIndex = 16;
            this.btnupdatestaff.Text = "Update";
            this.btnupdatestaff.UseVisualStyleBackColor = true;
            this.btnupdatestaff.Click += new System.EventHandler(this.btnupdatestaff_Click);
            // 
            // lblstaffinfo
            // 
            this.lblstaffinfo.AutoSize = true;
            this.lblstaffinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblstaffinfo.Location = new System.Drawing.Point(267, 13);
            this.lblstaffinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffinfo.Name = "lblstaffinfo";
            this.lblstaffinfo.Size = new System.Drawing.Size(186, 32);
            this.lblstaffinfo.TabIndex = 18;
            this.lblstaffinfo.Text = "Staff Information";
            // 
            // btnstaffinfoback
            // 
            this.btnstaffinfoback.Location = new System.Drawing.Point(48, 427);
            this.btnstaffinfoback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnstaffinfoback.Name = "btnstaffinfoback";
            this.btnstaffinfoback.Size = new System.Drawing.Size(80, 30);
            this.btnstaffinfoback.TabIndex = 19;
            this.btnstaffinfoback.Text = "Back";
            this.btnstaffinfoback.UseVisualStyleBackColor = true;
            this.btnstaffinfoback.Click += new System.EventHandler(this.btnstaffinfoback_Click);
            // 
            // lbldashboardstaffaddress
            // 
            this.lbldashboardstaffaddress.AutoSize = true;
            this.lbldashboardstaffaddress.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstaffaddress.Location = new System.Drawing.Point(496, 148);
            this.lbldashboardstaffaddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstaffaddress.Name = "lbldashboardstaffaddress";
            this.lbldashboardstaffaddress.Size = new System.Drawing.Size(52, 15);
            this.lbldashboardstaffaddress.TabIndex = 20;
            this.lbldashboardstaffaddress.Text = "Address:";
            // 
            // txtdashboardstaffaddress
            // 
            this.txtdashboardstaffaddress.Location = new System.Drawing.Point(574, 146);
            this.txtdashboardstaffaddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstaffaddress.Name = "txtdashboardstaffaddress";
            this.txtdashboardstaffaddress.Size = new System.Drawing.Size(211, 23);
            this.txtdashboardstaffaddress.TabIndex = 21;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(574, 173);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(211, 23);
            this.dateTimePicker1.TabIndex = 22;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // lbldashboardstaffdob
            // 
            this.lbldashboardstaffdob.AutoSize = true;
            this.lbldashboardstaffdob.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstaffdob.Location = new System.Drawing.Point(486, 176);
            this.lbldashboardstaffdob.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstaffdob.Name = "lbldashboardstaffdob";
            this.lbldashboardstaffdob.Size = new System.Drawing.Size(78, 15);
            this.lbldashboardstaffdob.TabIndex = 23;
            this.lbldashboardstaffdob.Text = "Date Of Birth:";
            // 
            // lbldashboardstaffpassword
            // 
            this.lbldashboardstaffpassword.AutoSize = true;
            this.lbldashboardstaffpassword.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstaffpassword.Location = new System.Drawing.Point(491, 244);
            this.lbldashboardstaffpassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstaffpassword.Name = "lbldashboardstaffpassword";
            this.lbldashboardstaffpassword.Size = new System.Drawing.Size(60, 15);
            this.lbldashboardstaffpassword.TabIndex = 24;
            this.lbldashboardstaffpassword.Text = "Password:";
            // 
            // txtdashboardstaffpassword
            // 
            this.txtdashboardstaffpassword.Location = new System.Drawing.Point(574, 242);
            this.txtdashboardstaffpassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstaffpassword.Name = "txtdashboardstaffpassword";
            this.txtdashboardstaffpassword.Size = new System.Drawing.Size(211, 23);
            this.txtdashboardstaffpassword.TabIndex = 25;
            // 
            // txtdashboardstaffphone
            // 
            this.txtdashboardstaffphone.Location = new System.Drawing.Point(574, 274);
            this.txtdashboardstaffphone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstaffphone.Name = "txtdashboardstaffphone";
            this.txtdashboardstaffphone.Size = new System.Drawing.Size(211, 23);
            this.txtdashboardstaffphone.TabIndex = 26;
            // 
            // lbldashboardstaffphone
            // 
            this.lbldashboardstaffphone.AutoSize = true;
            this.lbldashboardstaffphone.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstaffphone.Location = new System.Drawing.Point(496, 277);
            this.lbldashboardstaffphone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstaffphone.Name = "lbldashboardstaffphone";
            this.lbldashboardstaffphone.Size = new System.Drawing.Size(44, 15);
            this.lbldashboardstaffphone.TabIndex = 27;
            this.lbldashboardstaffphone.Text = "Phone:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(502, 308);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 28;
            this.label2.Text = "Salary:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(574, 307);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 23);
            this.textBox1.TabIndex = 29;
            // 
            // DashBoardStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbldashboardstaffphone);
            this.Controls.Add(this.txtdashboardstaffphone);
            this.Controls.Add(this.txtdashboardstaffpassword);
            this.Controls.Add(this.lbldashboardstaffpassword);
            this.Controls.Add(this.lbldashboardstaffdob);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtdashboardstaffaddress);
            this.Controls.Add(this.lbldashboardstaffaddress);
            this.Controls.Add(this.btnstaffinfoback);
            this.Controls.Add(this.lblstaffinfo);
            this.Controls.Add(this.btnupdatestaff);
            this.Controls.Add(this.btndeletestaff);
            this.Controls.Add(this.btninsertstaff);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnsearchstaff);
            this.Controls.Add(this.txtstaffid);
            this.Controls.Add(this.txtstaffname);
            this.Controls.Add(this.txtsearchstaffid);
            this.Controls.Add(this.lblstaffidsearch);
            this.Controls.Add(this.lblstaffid);
            this.Controls.Add(this.lblstaffname);
            this.Controls.Add(this.lblstaffdepartment);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "DashBoardStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashBoardStaff";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Label lblstaffdepartment;
        private Label lblstaffname;
        private Label lblstaffid;
        private Label lblstaffidsearch;
        private TextBox txtsearchstaffid;
        private TextBox txtstaffname;
        private TextBox txtstaffid;
        private Button btnsearchstaff;
        private ComboBox comboBox1;
        private Button btnload;
        private Button btninsertstaff;
        private Button btndeletestaff;
        private Button btnupdatestaff;
        private Label lblstaffinfo;
        private Button btnstaffinfoback;
        private Label lbldashboardstaffaddress;
        private TextBox txtdashboardstaffaddress;
        private DateTimePicker dateTimePicker1;
        private Label lbldashboardstaffdob;
        private Label lbldashboardstaffpassword;
        private TextBox txtdashboardstaffpassword;
        private TextBox txtdashboardstaffphone;
        private Label lbldashboardstaffphone;
        private Label label2;
        private TextBox textBox1;
        private DataGridViewTextBoxColumn ST_ID;
        private DataGridViewTextBoxColumn ST_Salary;
        private DataGridViewTextBoxColumn ST_Phone;
        private DataGridViewTextBoxColumn ST_Name;
        private DataGridViewTextBoxColumn ST_DOB;
        private DataGridViewTextBoxColumn ST_Address;
        private DataGridViewTextBoxColumn ST_Position;
    }
}