﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class DashBoardStaff : Form
    {
        public DashBoardStaff()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void Load()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select * from Staff";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Load();
        }

        private void btnstaffdone_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnstaffinfoback_Click(object sender, EventArgs e)
        {
            AdminDashBoard adb = new AdminDashBoard();
            this.Hide();
            adb.Show();
        }
       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView1.Rows[e.RowIndex].Cells["ST_ID"].Value.ToString();
            string name = dataGridView1.Rows[e.RowIndex].Cells["ST_Name"].Value.ToString();
            string salary = dataGridView1.Rows[e.RowIndex].Cells["ST_Salary"].Value.ToString();

            string address = dataGridView1.Rows[e.RowIndex].Cells["ST_Address"].Value.ToString();
            string phone = dataGridView1.Rows[e.RowIndex].Cells["ST_Phone"].Value.ToString();
            string department = dataGridView1.Rows[e.RowIndex].Cells["ST_Position"].Value.ToString();

            txtstaffid.Text = id;
            txtstaffname.Text = name;
            dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells["ST_DOB"].Value);
            txtdashboardstaffaddress.Text = address;
            txtdashboardstaffphone.Text = phone;
            comboBox1.Text = department;
            txtdashboardstaffpassword.Text = "";
            textBox1.Text= salary;  


        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtsearchstaffid_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsearchstaff_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from Staff where ST_ID like '" + txtsearchstaffid.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btninsertstaff_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO Staff( ST_Name, ST_Address, ST_Phone,ST_Position,ST_DOB,ST_Pass,ST_Jdate,ST_Salary) VALUES('" + txtstaffname.Text + "', '" + txtdashboardstaffaddress.Text + "', '" + txtdashboardstaffphone.Text + "','" + comboBox1.Text + "','" + dateTimePicker1.Value + "','" + txtdashboardstaffpassword.Text + "','" + DateTime.Now + "','"+textBox1.Text+"')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnupdatestaff_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Staff set ST_Name='" + txtstaffname.Text + "',ST_Address='" + txtdashboardstaffaddress.Text + "',ST_Phone='" + txtdashboardstaffphone.Text + "',ST_Position='" + comboBox1.Text + "',ST_DOB='" + dateTimePicker1.Value + "',ST_Pass='" + txtdashboardstaffpassword.Text + "',ST_Salary='"+textBox1.Text+"'where ST_ID =" + txtstaffid.Text;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            Load();
        }

        private void btndeletestaff_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string qu = "delete from Staff where ST_ID=" + txtstaffid.Text;
            SqlCommand cmd = new SqlCommand(qu, conn);
            cmd.ExecuteNonQuery();
            Load();
            txtstaffid.Text = " ";
            txtstaffname.Text = " ";
            comboBox1.Text = " ";
            txtdashboardstaffaddress.Text = " ";
            txtdashboardstaffphone.Text = " ";
            txtdashboardstaffpassword.Text = " ";
            textBox1.Text = " ";

           

        }

        private void txtstaffid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
