﻿namespace SchoolDataBaseManagementsln
{
    partial class DashBoardStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoardStudent));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.S_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_GPA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnload = new System.Windows.Forms.Button();
            this.lblStudentname = new System.Windows.Forms.Label();
            this.lblstudentid = new System.Windows.Forms.Label();
            this.lblStudentgpa = new System.Windows.Forms.Label();
            this.txtdashboardstudentid = new System.Windows.Forms.TextBox();
            this.txtdashboardstudentname = new System.Windows.Forms.TextBox();
            this.txtdashboardstudentgpa = new System.Windows.Forms.TextBox();
            this.btninsert = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.lblstudentinfo = new System.Windows.Forms.Label();
            this.btndashboardstudentback = new System.Windows.Forms.Button();
            this.lbldashboardstudentdob = new System.Windows.Forms.Label();
            this.dateTimePickerstudent = new System.Windows.Forms.DateTimePicker();
            this.lbldashboardstudentaddress = new System.Windows.Forms.Label();
            this.txtdashboardstudentaddress = new System.Windows.Forms.TextBox();
            this.lbldashboardstudentphone = new System.Windows.Forms.Label();
            this.txtsearchstudent = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnsearchstudent = new System.Windows.Forms.Button();
            this.txtdashboardstudentphone = new System.Windows.Forms.TextBox();
            this.lbldashboardstudentpassword = new System.Windows.Forms.Label();
            this.txtdashboardStudentpassword = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.S_ID,
            this.S_Name,
            this.S_DOB,
            this.S_Address,
            this.S_Phone,
            this.S_GPA});
            this.dataGridView1.Location = new System.Drawing.Point(8, 77);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(534, 205);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // S_ID
            // 
            this.S_ID.DataPropertyName = "S_ID";
            this.S_ID.HeaderText = "Student ID";
            this.S_ID.MinimumWidth = 8;
            this.S_ID.Name = "S_ID";
            this.S_ID.ReadOnly = true;
            this.S_ID.Width = 150;
            // 
            // S_Name
            // 
            this.S_Name.DataPropertyName = "S_Name";
            this.S_Name.HeaderText = "Student Name";
            this.S_Name.MinimumWidth = 8;
            this.S_Name.Name = "S_Name";
            this.S_Name.ReadOnly = true;
            this.S_Name.Width = 150;
            // 
            // S_DOB
            // 
            this.S_DOB.DataPropertyName = "S_DOB";
            this.S_DOB.HeaderText = "Student DOB";
            this.S_DOB.MinimumWidth = 8;
            this.S_DOB.Name = "S_DOB";
            this.S_DOB.ReadOnly = true;
            this.S_DOB.Width = 150;
            // 
            // S_Address
            // 
            this.S_Address.DataPropertyName = "S_Address";
            this.S_Address.HeaderText = "Student Address";
            this.S_Address.MinimumWidth = 8;
            this.S_Address.Name = "S_Address";
            this.S_Address.ReadOnly = true;
            this.S_Address.Width = 150;
            // 
            // S_Phone
            // 
            this.S_Phone.DataPropertyName = "S_Phone";
            this.S_Phone.HeaderText = "Student Phone";
            this.S_Phone.MinimumWidth = 8;
            this.S_Phone.Name = "S_Phone";
            this.S_Phone.ReadOnly = true;
            this.S_Phone.Width = 150;
            // 
            // S_GPA
            // 
            this.S_GPA.DataPropertyName = "S_GPA";
            this.S_GPA.HeaderText = "Student GPA";
            this.S_GPA.MinimumWidth = 8;
            this.S_GPA.Name = "S_GPA";
            this.S_GPA.ReadOnly = true;
            this.S_GPA.Width = 150;
            // 
            // btnload
            // 
            this.btnload.Location = new System.Drawing.Point(176, 308);
            this.btnload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(80, 30);
            this.btnload.TabIndex = 5;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = true;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // lblStudentname
            // 
            this.lblStudentname.AutoSize = true;
            this.lblStudentname.BackColor = System.Drawing.Color.Transparent;
            this.lblStudentname.Location = new System.Drawing.Point(547, 88);
            this.lblStudentname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStudentname.Name = "lblStudentname";
            this.lblStudentname.Size = new System.Drawing.Size(86, 15);
            this.lblStudentname.TabIndex = 6;
            this.lblStudentname.Text = "Student Name:";
            // 
            // lblstudentid
            // 
            this.lblstudentid.AutoSize = true;
            this.lblstudentid.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentid.Location = new System.Drawing.Point(557, 58);
            this.lblstudentid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentid.Name = "lblstudentid";
            this.lblstudentid.Size = new System.Drawing.Size(65, 15);
            this.lblstudentid.TabIndex = 7;
            this.lblstudentid.Text = "Student ID:";
            // 
            // lblStudentgpa
            // 
            this.lblStudentgpa.AutoSize = true;
            this.lblStudentgpa.BackColor = System.Drawing.Color.Transparent;
            this.lblStudentgpa.Location = new System.Drawing.Point(547, 121);
            this.lblStudentgpa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStudentgpa.Name = "lblStudentgpa";
            this.lblStudentgpa.Size = new System.Drawing.Size(76, 15);
            this.lblStudentgpa.TabIndex = 9;
            this.lblStudentgpa.Text = "Student GPA:";
            // 
            // txtdashboardstudentid
            // 
            this.txtdashboardstudentid.Location = new System.Drawing.Point(635, 54);
            this.txtdashboardstudentid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentid.Name = "txtdashboardstudentid";
            this.txtdashboardstudentid.ReadOnly = true;
            this.txtdashboardstudentid.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentid.TabIndex = 10;
            this.txtdashboardstudentid.TextChanged += new System.EventHandler(this.txtdashboardstudentid_TextChanged);
            // 
            // txtdashboardstudentname
            // 
            this.txtdashboardstudentname.Location = new System.Drawing.Point(635, 88);
            this.txtdashboardstudentname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentname.Name = "txtdashboardstudentname";
            this.txtdashboardstudentname.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentname.TabIndex = 12;
            // 
            // txtdashboardstudentgpa
            // 
            this.txtdashboardstudentgpa.Location = new System.Drawing.Point(635, 121);
            this.txtdashboardstudentgpa.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentgpa.Name = "txtdashboardstudentgpa";
            this.txtdashboardstudentgpa.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentgpa.TabIndex = 13;
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(566, 283);
            this.btninsert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(80, 30);
            this.btninsert.TabIndex = 14;
            this.btninsert.Text = "Insert";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(666, 283);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(80, 30);
            this.btnupdate.TabIndex = 15;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(772, 283);
            this.btndelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(80, 30);
            this.btndelete.TabIndex = 16;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // lblstudentinfo
            // 
            this.lblstudentinfo.AutoSize = true;
            this.lblstudentinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblstudentinfo.Location = new System.Drawing.Point(326, 7);
            this.lblstudentinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentinfo.Name = "lblstudentinfo";
            this.lblstudentinfo.Size = new System.Drawing.Size(220, 32);
            this.lblstudentinfo.TabIndex = 19;
            this.lblstudentinfo.Text = "Student Information";
            // 
            // btndashboardstudentback
            // 
            this.btndashboardstudentback.Location = new System.Drawing.Point(45, 425);
            this.btndashboardstudentback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btndashboardstudentback.Name = "btndashboardstudentback";
            this.btndashboardstudentback.Size = new System.Drawing.Size(80, 30);
            this.btndashboardstudentback.TabIndex = 20;
            this.btndashboardstudentback.Text = "Back";
            this.btndashboardstudentback.UseVisualStyleBackColor = true;
            this.btndashboardstudentback.Click += new System.EventHandler(this.btndashboardstudentback_Click_1);
            // 
            // lbldashboardstudentdob
            // 
            this.lbldashboardstudentdob.AutoSize = true;
            this.lbldashboardstudentdob.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentdob.Location = new System.Drawing.Point(547, 155);
            this.lbldashboardstudentdob.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentdob.Name = "lbldashboardstudentdob";
            this.lbldashboardstudentdob.Size = new System.Drawing.Size(78, 15);
            this.lbldashboardstudentdob.TabIndex = 21;
            this.lbldashboardstudentdob.Text = "Date Of Birth:";
            // 
            // dateTimePickerstudent
            // 
            this.dateTimePickerstudent.Location = new System.Drawing.Point(635, 155);
            this.dateTimePickerstudent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePickerstudent.Name = "dateTimePickerstudent";
            this.dateTimePickerstudent.Size = new System.Drawing.Size(217, 23);
            this.dateTimePickerstudent.TabIndex = 22;
            // 
            // lbldashboardstudentaddress
            // 
            this.lbldashboardstudentaddress.AutoSize = true;
            this.lbldashboardstudentaddress.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentaddress.Location = new System.Drawing.Point(570, 194);
            this.lbldashboardstudentaddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentaddress.Name = "lbldashboardstudentaddress";
            this.lbldashboardstudentaddress.Size = new System.Drawing.Size(52, 15);
            this.lbldashboardstudentaddress.TabIndex = 23;
            this.lbldashboardstudentaddress.Text = "Address:";
            // 
            // txtdashboardstudentaddress
            // 
            this.txtdashboardstudentaddress.Location = new System.Drawing.Point(635, 191);
            this.txtdashboardstudentaddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentaddress.Name = "txtdashboardstudentaddress";
            this.txtdashboardstudentaddress.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentaddress.TabIndex = 24;
            // 
            // lbldashboardstudentphone
            // 
            this.lbldashboardstudentphone.AutoSize = true;
            this.lbldashboardstudentphone.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentphone.Location = new System.Drawing.Point(581, 220);
            this.lbldashboardstudentphone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentphone.Name = "lbldashboardstudentphone";
            this.lbldashboardstudentphone.Size = new System.Drawing.Size(44, 15);
            this.lbldashboardstudentphone.TabIndex = 25;
            this.lbldashboardstudentphone.Text = "Phone:";
            // 
            // txtsearchstudent
            // 
            this.txtsearchstudent.Location = new System.Drawing.Point(158, 43);
            this.txtsearchstudent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtsearchstudent.Name = "txtsearchstudent";
            this.txtsearchstudent.Size = new System.Drawing.Size(128, 23);
            this.txtsearchstudent.TabIndex = 3;
            this.txtsearchstudent.TextChanged += new System.EventHandler(this.txtsearchstudent_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(83, 43);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Student ID:";
            // 
            // btnsearchstudent
            // 
            this.btnsearchstudent.Location = new System.Drawing.Point(305, 43);
            this.btnsearchstudent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsearchstudent.Name = "btnsearchstudent";
            this.btnsearchstudent.Size = new System.Drawing.Size(80, 30);
            this.btnsearchstudent.TabIndex = 4;
            this.btnsearchstudent.Text = "Search";
            this.btnsearchstudent.UseVisualStyleBackColor = true;
            this.btnsearchstudent.Click += new System.EventHandler(this.btnsearchstudent_Click);
            // 
            // txtdashboardstudentphone
            // 
            this.txtdashboardstudentphone.Location = new System.Drawing.Point(635, 218);
            this.txtdashboardstudentphone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentphone.Name = "txtdashboardstudentphone";
            this.txtdashboardstudentphone.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentphone.TabIndex = 26;
            // 
            // lbldashboardstudentpassword
            // 
            this.lbldashboardstudentpassword.AutoSize = true;
            this.lbldashboardstudentpassword.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentpassword.Location = new System.Drawing.Point(557, 250);
            this.lbldashboardstudentpassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentpassword.Name = "lbldashboardstudentpassword";
            this.lbldashboardstudentpassword.Size = new System.Drawing.Size(60, 15);
            this.lbldashboardstudentpassword.TabIndex = 27;
            this.lbldashboardstudentpassword.Text = "Password:";
            // 
            // txtdashboardStudentpassword
            // 
            this.txtdashboardStudentpassword.Location = new System.Drawing.Point(635, 250);
            this.txtdashboardStudentpassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardStudentpassword.Name = "txtdashboardStudentpassword";
            this.txtdashboardStudentpassword.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardStudentpassword.TabIndex = 28;
            // 
            // DashBoardStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.txtdashboardStudentpassword);
            this.Controls.Add(this.lbldashboardstudentpassword);
            this.Controls.Add(this.txtdashboardstudentphone);
            this.Controls.Add(this.lbldashboardstudentphone);
            this.Controls.Add(this.txtdashboardstudentaddress);
            this.Controls.Add(this.lbldashboardstudentaddress);
            this.Controls.Add(this.dateTimePickerstudent);
            this.Controls.Add(this.lbldashboardstudentdob);
            this.Controls.Add(this.btndashboardstudentback);
            this.Controls.Add(this.lblstudentinfo);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.txtdashboardstudentgpa);
            this.Controls.Add(this.txtdashboardstudentname);
            this.Controls.Add(this.txtdashboardstudentid);
            this.Controls.Add(this.lblStudentgpa);
            this.Controls.Add(this.lblstudentid);
            this.Controls.Add(this.lblStudentname);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.btnsearchstudent);
            this.Controls.Add(this.txtsearchstudent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "DashBoardStudent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashBoardStudent";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnload;
        private Label lblStudentname;
        private Label lblstudentid;
        private Label lblStudentgpa;
        private TextBox txtdashboardstudentid;
        private TextBox txtdashboardstudentname;
        private TextBox txtdashboardstudentgpa;
        private Button btninsert;
        private Button btnupdate;
        private Button btndelete;
        private Label lblstudentinfo;
        private Button btndashboardstudentback;
        private Label lbldashboardstudentdob;
        private DateTimePicker dateTimePickerstudent;
        private Label lbldashboardstudentaddress;
        private TextBox txtdashboardstudentaddress;
        private DataGridViewTextBoxColumn S_ID;
        private DataGridViewTextBoxColumn S_Name;
        private DataGridViewTextBoxColumn S_DOB;
        private DataGridViewTextBoxColumn S_Address;
        private DataGridViewTextBoxColumn S_Phone;
        private DataGridViewTextBoxColumn S_GPA;
        private Label lbldashboardstudentphone;
        private TextBox txtsearchstudent;
        private Label label2;
        private Button btnsearchstudent;
        private TextBox txtdashboardstudentphone;
        private Label lbldashboardstudentpassword;
        private TextBox txtdashboardStudentpassword;
    }
}