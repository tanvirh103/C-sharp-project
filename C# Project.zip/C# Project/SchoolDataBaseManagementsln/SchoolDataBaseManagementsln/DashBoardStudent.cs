﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SchoolDataBaseManagementsln
{
    public partial class DashBoardStudent : Form
    {
        public DashBoardStudent()
        {
            InitializeComponent();
        }

        private void btnstudentdone_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btndashboardstudentback_Click(object sender, EventArgs e)
        {
            AdminDashBoard adb= new AdminDashBoard();
            this.Hide();
            adb.Show();
        }
        public void Load() {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select * from Student";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btndashboardstudentback_Click_1(object sender, EventArgs e)
        {
            AdminDashBoard adb=new AdminDashBoard();
            this.Close();
            adb.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView1.Rows[e.RowIndex].Cells["S_ID"].Value.ToString();
            string name = dataGridView1.Rows[e.RowIndex].Cells["S_Name"].Value.ToString();
            
            string address = dataGridView1.Rows[e.RowIndex].Cells["S_Address"].Value.ToString();
            string phone = dataGridView1.Rows[e.RowIndex].Cells["S_Phone"].Value.ToString();
            string  GPA = dataGridView1.Rows[e.RowIndex].Cells["S_GPA"].Value.ToString();

            txtdashboardstudentid.Text = id;
            txtdashboardstudentname.Text = name;
            dateTimePickerstudent.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells["S_DOB"].Value);
            txtdashboardstudentaddress.Text = address;
            txtdashboardstudentphone.Text = phone;
            txtdashboardstudentgpa.Text = GPA;
            txtdashboardStudentpassword.Text = "";


        }

        private void btnload_Click(object sender, EventArgs e)
        {
            Load();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Student set S_Name='"+txtdashboardstudentname.Text+"',S_Address='"+txtdashboardstudentaddress.Text+"',S_Phone='"+txtdashboardstudentphone.Text+"',S_GPA='"+txtdashboardstudentgpa.Text+"',S_DOB='"+ dateTimePickerstudent.Value+"',S_Pass='"+ txtdashboardStudentpassword.Text+"'where S_ID ="+txtdashboardstudentid.Text;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            Load();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO Student( S_Name, S_Address, S_Phone,S_GPA,S_DOB,S_Pass) VALUES('" + txtdashboardstudentname.Text + "', '" + txtdashboardstudentaddress.Text + "', '" + txtdashboardstudentphone.Text + "','" + txtdashboardstudentgpa.Text +"','" + dateTimePickerstudent.Value +"','"+txtdashboardStudentpassword.Text+"')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string qu = "delete from Student where S_ID=" + txtdashboardstudentid.Text;
            SqlCommand cmd=new SqlCommand(qu, conn);
            cmd.ExecuteNonQuery();
            Load();
            txtdashboardstudentid.Text= " ";
            txtdashboardstudentname.Text= " ";
            txtdashboardstudentgpa.Text= " ";   
            txtdashboardstudentaddress.Text= " ";   
            txtdashboardstudentphone.Text= " ";
            txtdashboardStudentpassword.Text = " ";
            

        }

        private void btnsearchstudent_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from Student where S_ID like '" + txtsearchstudent.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();

        }

        private void txtsearchstudent_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtdashboardstudentid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
