﻿namespace SchoolDataBaseManagementsln
{
    partial class DashBoardTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoardTeacher));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.T_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSearchteacher = new System.Windows.Forms.Label();
            this.lbldashboardTeacherName = new System.Windows.Forms.Label();
            this.lblTeacherId = new System.Windows.Forms.Label();
            this.lblsearchteacherid = new System.Windows.Forms.Label();
            this.txtTeachersearchid = new System.Windows.Forms.TextBox();
            this.btnload = new System.Windows.Forms.Button();
            this.btnSearchTeacher = new System.Windows.Forms.Button();
            this.btndeleteteacher = new System.Windows.Forms.Button();
            this.btnupdateteacher = new System.Windows.Forms.Button();
            this.btninsertteacher = new System.Windows.Forms.Button();
            this.txtdashboardteachername = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btndashboardteacherback = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbldashboardteacherdob = new System.Windows.Forms.Label();
            this.lbldashboardteacheraddress = new System.Windows.Forms.Label();
            this.lbldashboardteacherphone = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbldashboardteacherpassword = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.Salary = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.T_ID,
            this.T_Salary,
            this.T_Name,
            this.T_DOB,
            this.T_Address,
            this.T_Phone});
            this.dataGridView1.Location = new System.Drawing.Point(17, 44);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(507, 205);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // T_ID
            // 
            this.T_ID.DataPropertyName = "T_ID";
            this.T_ID.HeaderText = "Teacher ID";
            this.T_ID.MinimumWidth = 8;
            this.T_ID.Name = "T_ID";
            this.T_ID.ReadOnly = true;
            this.T_ID.Width = 150;
            // 
            // T_Salary
            // 
            this.T_Salary.DataPropertyName = "T_Salary";
            this.T_Salary.HeaderText = "Salary";
            this.T_Salary.MinimumWidth = 8;
            this.T_Salary.Name = "T_Salary";
            this.T_Salary.ReadOnly = true;
            this.T_Salary.Width = 150;
            // 
            // T_Name
            // 
            this.T_Name.DataPropertyName = "T_Name";
            this.T_Name.HeaderText = "Teacher Name";
            this.T_Name.MinimumWidth = 8;
            this.T_Name.Name = "T_Name";
            this.T_Name.ReadOnly = true;
            this.T_Name.Width = 150;
            // 
            // T_DOB
            // 
            this.T_DOB.DataPropertyName = "T_DOB";
            this.T_DOB.HeaderText = "Teacher DOB";
            this.T_DOB.MinimumWidth = 8;
            this.T_DOB.Name = "T_DOB";
            this.T_DOB.ReadOnly = true;
            this.T_DOB.Width = 150;
            // 
            // T_Address
            // 
            this.T_Address.DataPropertyName = "T_Address";
            this.T_Address.HeaderText = "Teacher Address";
            this.T_Address.MinimumWidth = 8;
            this.T_Address.Name = "T_Address";
            this.T_Address.ReadOnly = true;
            this.T_Address.Width = 150;
            // 
            // T_Phone
            // 
            this.T_Phone.DataPropertyName = "T_Phone";
            this.T_Phone.HeaderText = "Teacher Phone";
            this.T_Phone.MinimumWidth = 8;
            this.T_Phone.Name = "T_Phone";
            this.T_Phone.ReadOnly = true;
            this.T_Phone.Width = 150;
            // 
            // lblSearchteacher
            // 
            this.lblSearchteacher.AutoSize = true;
            this.lblSearchteacher.BackColor = System.Drawing.Color.Transparent;
            this.lblSearchteacher.Location = new System.Drawing.Point(665, 19);
            this.lblSearchteacher.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSearchteacher.Name = "lblSearchteacher";
            this.lblSearchteacher.Size = new System.Drawing.Size(85, 15);
            this.lblSearchteacher.TabIndex = 1;
            this.lblSearchteacher.Text = "Search Teacher";
            // 
            // lbldashboardTeacherName
            // 
            this.lbldashboardTeacherName.AutoSize = true;
            this.lbldashboardTeacherName.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardTeacherName.Location = new System.Drawing.Point(532, 114);
            this.lbldashboardTeacherName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardTeacherName.Name = "lbldashboardTeacherName";
            this.lbldashboardTeacherName.Size = new System.Drawing.Size(85, 15);
            this.lbldashboardTeacherName.TabIndex = 3;
            this.lbldashboardTeacherName.Text = "Teacher Name:";
            // 
            // lblTeacherId
            // 
            this.lblTeacherId.AutoSize = true;
            this.lblTeacherId.BackColor = System.Drawing.Color.Transparent;
            this.lblTeacherId.Location = new System.Drawing.Point(533, 78);
            this.lblTeacherId.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTeacherId.Name = "lblTeacherId";
            this.lblTeacherId.Size = new System.Drawing.Size(64, 15);
            this.lblTeacherId.TabIndex = 4;
            this.lblTeacherId.Text = "Teacher ID:";
            // 
            // lblsearchteacherid
            // 
            this.lblsearchteacherid.AutoSize = true;
            this.lblsearchteacherid.BackColor = System.Drawing.Color.Transparent;
            this.lblsearchteacherid.Location = new System.Drawing.Point(532, 44);
            this.lblsearchteacherid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsearchteacherid.Name = "lblsearchteacherid";
            this.lblsearchteacherid.Size = new System.Drawing.Size(64, 15);
            this.lblsearchteacherid.TabIndex = 5;
            this.lblsearchteacherid.Text = "Teacher ID:";
            // 
            // txtTeachersearchid
            // 
            this.txtTeachersearchid.Location = new System.Drawing.Point(621, 44);
            this.txtTeachersearchid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTeachersearchid.Name = "txtTeachersearchid";
            this.txtTeachersearchid.Size = new System.Drawing.Size(182, 23);
            this.txtTeachersearchid.TabIndex = 6;
            // 
            // btnload
            // 
            this.btnload.Location = new System.Drawing.Point(228, 262);
            this.btnload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(80, 30);
            this.btnload.TabIndex = 7;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = true;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // btnSearchTeacher
            // 
            this.btnSearchTeacher.Location = new System.Drawing.Point(807, 39);
            this.btnSearchTeacher.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSearchTeacher.Name = "btnSearchTeacher";
            this.btnSearchTeacher.Size = new System.Drawing.Size(80, 30);
            this.btnSearchTeacher.TabIndex = 8;
            this.btnSearchTeacher.Text = "Search";
            this.btnSearchTeacher.UseVisualStyleBackColor = true;
            this.btnSearchTeacher.Click += new System.EventHandler(this.btnSearchTeacher_Click);
            // 
            // btndeleteteacher
            // 
            this.btndeleteteacher.Location = new System.Drawing.Point(770, 319);
            this.btndeleteteacher.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btndeleteteacher.Name = "btndeleteteacher";
            this.btndeleteteacher.Size = new System.Drawing.Size(80, 30);
            this.btndeleteteacher.TabIndex = 9;
            this.btndeleteteacher.Text = "Delete";
            this.btndeleteteacher.UseVisualStyleBackColor = true;
            this.btndeleteteacher.Click += new System.EventHandler(this.btndeleteteacher_Click);
            // 
            // btnupdateteacher
            // 
            this.btnupdateteacher.Location = new System.Drawing.Point(651, 319);
            this.btnupdateteacher.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnupdateteacher.Name = "btnupdateteacher";
            this.btnupdateteacher.Size = new System.Drawing.Size(80, 30);
            this.btnupdateteacher.TabIndex = 10;
            this.btnupdateteacher.Text = "Update";
            this.btnupdateteacher.UseVisualStyleBackColor = true;
            this.btnupdateteacher.Click += new System.EventHandler(this.btnupdateteacher_Click);
            // 
            // btninsertteacher
            // 
            this.btninsertteacher.Location = new System.Drawing.Point(535, 319);
            this.btninsertteacher.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btninsertteacher.Name = "btninsertteacher";
            this.btninsertteacher.Size = new System.Drawing.Size(80, 30);
            this.btninsertteacher.TabIndex = 11;
            this.btninsertteacher.Text = "Insert";
            this.btninsertteacher.UseVisualStyleBackColor = true;
            this.btninsertteacher.Click += new System.EventHandler(this.btninsertteacher_Click);
            // 
            // txtdashboardteachername
            // 
            this.txtdashboardteachername.Location = new System.Drawing.Point(621, 112);
            this.txtdashboardteachername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardteachername.Name = "txtdashboardteachername";
            this.txtdashboardteachername.Size = new System.Drawing.Size(210, 23);
            this.txtdashboardteachername.TabIndex = 14;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(621, 78);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(210, 23);
            this.textBox4.TabIndex = 15;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // btndashboardteacherback
            // 
            this.btndashboardteacherback.Location = new System.Drawing.Point(53, 413);
            this.btndashboardteacherback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btndashboardteacherback.Name = "btndashboardteacherback";
            this.btndashboardteacherback.Size = new System.Drawing.Size(80, 30);
            this.btndashboardteacherback.TabIndex = 21;
            this.btndashboardteacherback.Text = "Back";
            this.btndashboardteacherback.UseVisualStyleBackColor = true;
            this.btndashboardteacherback.Click += new System.EventHandler(this.btndashboardteacherback_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(339, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 32);
            this.label1.TabIndex = 22;
            this.label1.Text = "Teacher Information\r\n";
            // 
            // lbldashboardteacherdob
            // 
            this.lbldashboardteacherdob.AutoSize = true;
            this.lbldashboardteacherdob.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardteacherdob.Location = new System.Drawing.Point(532, 187);
            this.lbldashboardteacherdob.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardteacherdob.Name = "lbldashboardteacherdob";
            this.lbldashboardteacherdob.Size = new System.Drawing.Size(78, 15);
            this.lbldashboardteacherdob.TabIndex = 23;
            this.lbldashboardteacherdob.Text = "Date Of Birth:";
            // 
            // lbldashboardteacheraddress
            // 
            this.lbldashboardteacheraddress.AutoSize = true;
            this.lbldashboardteacheraddress.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardteacheraddress.Location = new System.Drawing.Point(531, 222);
            this.lbldashboardteacheraddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardteacheraddress.Name = "lbldashboardteacheraddress";
            this.lbldashboardteacheraddress.Size = new System.Drawing.Size(52, 15);
            this.lbldashboardteacheraddress.TabIndex = 24;
            this.lbldashboardteacheraddress.Text = "Address:";
            // 
            // lbldashboardteacherphone
            // 
            this.lbldashboardteacherphone.AutoSize = true;
            this.lbldashboardteacherphone.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardteacherphone.Location = new System.Drawing.Point(532, 257);
            this.lbldashboardteacherphone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardteacherphone.Name = "lbldashboardteacherphone";
            this.lbldashboardteacherphone.Size = new System.Drawing.Size(91, 15);
            this.lbldashboardteacherphone.TabIndex = 25;
            this.lbldashboardteacherphone.Text = "Phone Number:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(620, 220);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 23);
            this.textBox1.TabIndex = 26;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(626, 256);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(205, 23);
            this.textBox2.TabIndex = 27;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(620, 187);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(211, 23);
            this.dateTimePicker1.TabIndex = 28;
            // 
            // lbldashboardteacherpassword
            // 
            this.lbldashboardteacherpassword.AutoSize = true;
            this.lbldashboardteacherpassword.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardteacherpassword.Location = new System.Drawing.Point(532, 155);
            this.lbldashboardteacherpassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardteacherpassword.Name = "lbldashboardteacherpassword";
            this.lbldashboardteacherpassword.Size = new System.Drawing.Size(60, 15);
            this.lbldashboardteacherpassword.TabIndex = 29;
            this.lbldashboardteacherpassword.Text = "Password:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(620, 155);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(211, 23);
            this.textBox3.TabIndex = 30;
            // 
            // Salary
            // 
            this.Salary.AutoSize = true;
            this.Salary.BackColor = System.Drawing.Color.Transparent;
            this.Salary.Location = new System.Drawing.Point(535, 288);
            this.Salary.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(41, 15);
            this.Salary.TabIndex = 31;
            this.Salary.Text = "Salary:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(624, 288);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(207, 23);
            this.textBox5.TabIndex = 32;
            // 
            // DashBoardTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.Salary);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.lbldashboardteacherpassword);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbldashboardteacherphone);
            this.Controls.Add(this.lbldashboardteacheraddress);
            this.Controls.Add(this.lbldashboardteacherdob);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btndashboardteacherback);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.txtdashboardteachername);
            this.Controls.Add(this.btninsertteacher);
            this.Controls.Add(this.btnupdateteacher);
            this.Controls.Add(this.btndeleteteacher);
            this.Controls.Add(this.btnSearchTeacher);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.txtTeachersearchid);
            this.Controls.Add(this.lblsearchteacherid);
            this.Controls.Add(this.lblTeacherId);
            this.Controls.Add(this.lbldashboardTeacherName);
            this.Controls.Add(this.lblSearchteacher);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "DashBoardTeacher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashBoardTeacher";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Label lblSearchteacher;
        private Label lbldashboardTeacherName;
        private Label lblTeacherId;
        private Label lblsearchteacherid;
        private TextBox txtTeachersearchid;
        private Button btnload;
        private Button btnSearchTeacher;
        private Button btndeleteteacher;
        private Button btnupdateteacher;
        private Button btninsertteacher;
        private TextBox txtdashboardteachername;
        private TextBox textBox4;
        private Button btndashboardteacherback;
        private Label label1;
        private Label lbldashboardteacherdob;
        private Label lbldashboardteacheraddress;
        private Label lbldashboardteacherphone;
        private TextBox textBox1;
        private TextBox textBox2;
        private DateTimePicker dateTimePicker1;
        private Label lbldashboardteacherpassword;
        private TextBox textBox3;
        private Label Salary;
        private TextBox textBox5;
        private DataGridViewTextBoxColumn T_ID;
        private DataGridViewTextBoxColumn T_Salary;
        private DataGridViewTextBoxColumn T_Name;
        private DataGridViewTextBoxColumn T_DOB;
        private DataGridViewTextBoxColumn T_Address;
        private DataGridViewTextBoxColumn T_Phone;
    }
}