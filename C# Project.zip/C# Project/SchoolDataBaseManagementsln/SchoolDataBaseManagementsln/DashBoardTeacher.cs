﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SchoolDataBaseManagementsln
{
    public partial class DashBoardTeacher : Form
    {
        public DashBoardTeacher()
        {
            InitializeComponent();
           // load();
        }

        private void btndone_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btndashboardteacherback_Click(object sender, EventArgs e)
        {
            AdminDashBoard adb = new AdminDashBoard();
            this.Hide();
            adb.Show();
        }
        public void load()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select * from Teacher";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            load();
        }

        private void btnupdateteacher_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Teacher set T_Name='" + txtdashboardteachername.Text + "',T_Address='" + textBox1.Text + "',T_Phone='" + textBox2.Text + "',T_Pass='" + textBox3.Text + "',T_DOB='" + dateTimePicker1.Value + "',T_Salary='"+textBox5.Text+"' where T_ID =" + textBox4.Text;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            load();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btninsertteacher_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO Teacher( T_Name, T_Address, T_Phone,T_Pass,T_DOB,T_Jdate,T_Salary) VALUES('" + txtdashboardteachername.Text + "', '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + dateTimePicker1.Value + "','" + DateTime.Now +"','"+ textBox5.Text+"')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();

        }

        private void btndeleteteacher_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string qu = "delete from Teacher where T_ID=" + textBox4.Text;
            SqlCommand cmd = new SqlCommand(qu, conn);
            cmd.ExecuteNonQuery();
            load();
            textBox4.Text = " ";
            txtdashboardteachername.Text = " ";
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox5.Text = " ";
            
        }

        private void btnSearchTeacher_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from Teacher where T_ID like '" + txtTeachersearchid.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            string id = dataGridView1.Rows[e.RowIndex].Cells["T_ID"].Value.ToString();
            string name = dataGridView1.Rows[e.RowIndex].Cells["T_Name"].Value.ToString();
            string salary = dataGridView1.Rows[e.RowIndex].Cells["T_Salary"].Value.ToString();
            string address = dataGridView1.Rows[e.RowIndex].Cells["T_Address"].Value.ToString();
            string phone = dataGridView1.Rows[e.RowIndex].Cells["T_Phone"].Value.ToString();


            textBox4.Text = id;
            txtdashboardteachername.Text = name;
            dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells["T_DOB"].Value);
            textBox1.Text = address;
            textBox2.Text = phone;
            textBox3.Text = "";
            textBox5.Text = salary;


        }
    }
}

