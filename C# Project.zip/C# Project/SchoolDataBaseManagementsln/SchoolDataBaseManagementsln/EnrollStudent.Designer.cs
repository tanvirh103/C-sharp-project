﻿namespace SchoolDataBaseManagementsln
{
    partial class EnrollStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EnrollStudent));
            this.txtdashboardStudentpassword = new System.Windows.Forms.TextBox();
            this.lbldashboardstudentpassword = new System.Windows.Forms.Label();
            this.txtdashboardstudentphone = new System.Windows.Forms.TextBox();
            this.lbldashboardstudentphone = new System.Windows.Forms.Label();
            this.txtdashboardstudentaddress = new System.Windows.Forms.TextBox();
            this.lbldashboardstudentaddress = new System.Windows.Forms.Label();
            this.dateTimePickerstudent = new System.Windows.Forms.DateTimePicker();
            this.lbldashboardstudentdob = new System.Windows.Forms.Label();
            this.lblstudentinfo = new System.Windows.Forms.Label();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btninsert = new System.Windows.Forms.Button();
            this.txtdashboardstudentgpa = new System.Windows.Forms.TextBox();
            this.txtdashboardstudentname = new System.Windows.Forms.TextBox();
            this.txtdashboardstudentid = new System.Windows.Forms.TextBox();
            this.lblStudentgpa = new System.Windows.Forms.Label();
            this.lblstudentid = new System.Windows.Forms.Label();
            this.lblStudentname = new System.Windows.Forms.Label();
            this.btnload = new System.Windows.Forms.Button();
            this.btnsearchstudent = new System.Windows.Forms.Button();
            this.txtsearchstudent = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.S_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_GPA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnenrollmentback = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtdashboardStudentpassword
            // 
            this.txtdashboardStudentpassword.Location = new System.Drawing.Point(653, 277);
            this.txtdashboardStudentpassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardStudentpassword.Name = "txtdashboardStudentpassword";
            this.txtdashboardStudentpassword.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardStudentpassword.TabIndex = 52;
            // 
            // lbldashboardstudentpassword
            // 
            this.lbldashboardstudentpassword.AutoSize = true;
            this.lbldashboardstudentpassword.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentpassword.Location = new System.Drawing.Point(575, 277);
            this.lbldashboardstudentpassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentpassword.Name = "lbldashboardstudentpassword";
            this.lbldashboardstudentpassword.Size = new System.Drawing.Size(60, 15);
            this.lbldashboardstudentpassword.TabIndex = 51;
            this.lbldashboardstudentpassword.Text = "Password:";
            // 
            // txtdashboardstudentphone
            // 
            this.txtdashboardstudentphone.Location = new System.Drawing.Point(653, 245);
            this.txtdashboardstudentphone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentphone.Name = "txtdashboardstudentphone";
            this.txtdashboardstudentphone.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentphone.TabIndex = 50;
            // 
            // lbldashboardstudentphone
            // 
            this.lbldashboardstudentphone.AutoSize = true;
            this.lbldashboardstudentphone.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentphone.Location = new System.Drawing.Point(599, 247);
            this.lbldashboardstudentphone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentphone.Name = "lbldashboardstudentphone";
            this.lbldashboardstudentphone.Size = new System.Drawing.Size(44, 15);
            this.lbldashboardstudentphone.TabIndex = 49;
            this.lbldashboardstudentphone.Text = "Phone:";
            // 
            // txtdashboardstudentaddress
            // 
            this.txtdashboardstudentaddress.Location = new System.Drawing.Point(653, 218);
            this.txtdashboardstudentaddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentaddress.Name = "txtdashboardstudentaddress";
            this.txtdashboardstudentaddress.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentaddress.TabIndex = 48;
            // 
            // lbldashboardstudentaddress
            // 
            this.lbldashboardstudentaddress.AutoSize = true;
            this.lbldashboardstudentaddress.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentaddress.Location = new System.Drawing.Point(589, 221);
            this.lbldashboardstudentaddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentaddress.Name = "lbldashboardstudentaddress";
            this.lbldashboardstudentaddress.Size = new System.Drawing.Size(52, 15);
            this.lbldashboardstudentaddress.TabIndex = 47;
            this.lbldashboardstudentaddress.Text = "Address:";
            // 
            // dateTimePickerstudent
            // 
            this.dateTimePickerstudent.CustomFormat = "";
            this.dateTimePickerstudent.Location = new System.Drawing.Point(653, 182);
            this.dateTimePickerstudent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePickerstudent.Name = "dateTimePickerstudent";
            this.dateTimePickerstudent.Size = new System.Drawing.Size(217, 23);
            this.dateTimePickerstudent.TabIndex = 46;
            this.dateTimePickerstudent.ValueChanged += new System.EventHandler(this.dateTimePickerstudent_ValueChanged);
            // 
            // lbldashboardstudentdob
            // 
            this.lbldashboardstudentdob.AutoSize = true;
            this.lbldashboardstudentdob.BackColor = System.Drawing.Color.Transparent;
            this.lbldashboardstudentdob.Location = new System.Drawing.Point(565, 182);
            this.lbldashboardstudentdob.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldashboardstudentdob.Name = "lbldashboardstudentdob";
            this.lbldashboardstudentdob.Size = new System.Drawing.Size(78, 15);
            this.lbldashboardstudentdob.TabIndex = 45;
            this.lbldashboardstudentdob.Text = "Date Of Birth:";
            // 
            // lblstudentinfo
            // 
            this.lblstudentinfo.AutoSize = true;
            this.lblstudentinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblstudentinfo.Location = new System.Drawing.Point(342, 23);
            this.lblstudentinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentinfo.Name = "lblstudentinfo";
            this.lblstudentinfo.Size = new System.Drawing.Size(220, 32);
            this.lblstudentinfo.TabIndex = 43;
            this.lblstudentinfo.Text = "Student Information";
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(771, 312);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(80, 30);
            this.btnupdate.TabIndex = 41;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(653, 312);
            this.btninsert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(80, 30);
            this.btninsert.TabIndex = 40;
            this.btninsert.Text = "Insert";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // txtdashboardstudentgpa
            // 
            this.txtdashboardstudentgpa.Location = new System.Drawing.Point(653, 148);
            this.txtdashboardstudentgpa.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentgpa.Name = "txtdashboardstudentgpa";
            this.txtdashboardstudentgpa.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentgpa.TabIndex = 39;
            // 
            // txtdashboardstudentname
            // 
            this.txtdashboardstudentname.Location = new System.Drawing.Point(653, 115);
            this.txtdashboardstudentname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentname.Name = "txtdashboardstudentname";
            this.txtdashboardstudentname.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentname.TabIndex = 38;
            // 
            // txtdashboardstudentid
            // 
            this.txtdashboardstudentid.Location = new System.Drawing.Point(653, 81);
            this.txtdashboardstudentid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtdashboardstudentid.Name = "txtdashboardstudentid";
            this.txtdashboardstudentid.ReadOnly = true;
            this.txtdashboardstudentid.Size = new System.Drawing.Size(217, 23);
            this.txtdashboardstudentid.TabIndex = 37;
            // 
            // lblStudentgpa
            // 
            this.lblStudentgpa.AutoSize = true;
            this.lblStudentgpa.BackColor = System.Drawing.Color.Transparent;
            this.lblStudentgpa.Location = new System.Drawing.Point(565, 148);
            this.lblStudentgpa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStudentgpa.Name = "lblStudentgpa";
            this.lblStudentgpa.Size = new System.Drawing.Size(76, 15);
            this.lblStudentgpa.TabIndex = 36;
            this.lblStudentgpa.Text = "Student GPA:";
            // 
            // lblstudentid
            // 
            this.lblstudentid.AutoSize = true;
            this.lblstudentid.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentid.Location = new System.Drawing.Point(575, 85);
            this.lblstudentid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentid.Name = "lblstudentid";
            this.lblstudentid.Size = new System.Drawing.Size(65, 15);
            this.lblstudentid.TabIndex = 35;
            this.lblstudentid.Text = "Student ID:";
            // 
            // lblStudentname
            // 
            this.lblStudentname.AutoSize = true;
            this.lblStudentname.BackColor = System.Drawing.Color.Transparent;
            this.lblStudentname.Location = new System.Drawing.Point(565, 115);
            this.lblStudentname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStudentname.Name = "lblStudentname";
            this.lblStudentname.Size = new System.Drawing.Size(86, 15);
            this.lblStudentname.TabIndex = 34;
            this.lblStudentname.Text = "Student Name:";
            // 
            // btnload
            // 
            this.btnload.Location = new System.Drawing.Point(195, 335);
            this.btnload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(80, 30);
            this.btnload.TabIndex = 33;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = true;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // btnsearchstudent
            // 
            this.btnsearchstudent.Location = new System.Drawing.Point(323, 70);
            this.btnsearchstudent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsearchstudent.Name = "btnsearchstudent";
            this.btnsearchstudent.Size = new System.Drawing.Size(80, 30);
            this.btnsearchstudent.TabIndex = 32;
            this.btnsearchstudent.Text = "Search";
            this.btnsearchstudent.UseVisualStyleBackColor = true;
            this.btnsearchstudent.Click += new System.EventHandler(this.btnsearchstudent_Click);
            // 
            // txtsearchstudent
            // 
            this.txtsearchstudent.Location = new System.Drawing.Point(176, 70);
            this.txtsearchstudent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtsearchstudent.Name = "txtsearchstudent";
            this.txtsearchstudent.Size = new System.Drawing.Size(128, 23);
            this.txtsearchstudent.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(101, 70);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 30;
            this.label2.Text = "Student ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.S_ID,
            this.S_Name,
            this.S_DOB,
            this.S_Address,
            this.S_Phone,
            this.S_GPA});
            this.dataGridView1.Location = new System.Drawing.Point(18, 103);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(534, 205);
            this.dataGridView1.TabIndex = 29;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // S_ID
            // 
            this.S_ID.DataPropertyName = "S_ID";
            this.S_ID.HeaderText = "Student ID";
            this.S_ID.MinimumWidth = 8;
            this.S_ID.Name = "S_ID";
            this.S_ID.ReadOnly = true;
            this.S_ID.Width = 150;
            // 
            // S_Name
            // 
            this.S_Name.DataPropertyName = "S_Name";
            this.S_Name.HeaderText = "Student Name";
            this.S_Name.MinimumWidth = 8;
            this.S_Name.Name = "S_Name";
            this.S_Name.ReadOnly = true;
            this.S_Name.Width = 150;
            // 
            // S_DOB
            // 
            this.S_DOB.DataPropertyName = "S_DOB";
            this.S_DOB.HeaderText = "Student DOB";
            this.S_DOB.MinimumWidth = 8;
            this.S_DOB.Name = "S_DOB";
            this.S_DOB.ReadOnly = true;
            this.S_DOB.Width = 150;
            // 
            // S_Address
            // 
            this.S_Address.DataPropertyName = "S_Address";
            this.S_Address.HeaderText = "Student Address";
            this.S_Address.MinimumWidth = 8;
            this.S_Address.Name = "S_Address";
            this.S_Address.ReadOnly = true;
            this.S_Address.Width = 150;
            // 
            // S_Phone
            // 
            this.S_Phone.DataPropertyName = "S_Phone";
            this.S_Phone.HeaderText = "Student Phone";
            this.S_Phone.MinimumWidth = 8;
            this.S_Phone.Name = "S_Phone";
            this.S_Phone.ReadOnly = true;
            this.S_Phone.Width = 150;
            // 
            // S_GPA
            // 
            this.S_GPA.DataPropertyName = "S_GPA";
            this.S_GPA.HeaderText = "Student GPA";
            this.S_GPA.MinimumWidth = 8;
            this.S_GPA.Name = "S_GPA";
            this.S_GPA.ReadOnly = true;
            this.S_GPA.Width = 150;
            // 
            // btnenrollmentback
            // 
            this.btnenrollmentback.Location = new System.Drawing.Point(92, 440);
            this.btnenrollmentback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnenrollmentback.Name = "btnenrollmentback";
            this.btnenrollmentback.Size = new System.Drawing.Size(80, 30);
            this.btnenrollmentback.TabIndex = 53;
            this.btnenrollmentback.Text = "Back";
            this.btnenrollmentback.UseVisualStyleBackColor = true;
            this.btnenrollmentback.Click += new System.EventHandler(this.btnenrollmentback_Click);
            // 
            // EnrollStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.btnenrollmentback);
            this.Controls.Add(this.txtdashboardStudentpassword);
            this.Controls.Add(this.lbldashboardstudentpassword);
            this.Controls.Add(this.txtdashboardstudentphone);
            this.Controls.Add(this.lbldashboardstudentphone);
            this.Controls.Add(this.txtdashboardstudentaddress);
            this.Controls.Add(this.lbldashboardstudentaddress);
            this.Controls.Add(this.dateTimePickerstudent);
            this.Controls.Add(this.lbldashboardstudentdob);
            this.Controls.Add(this.lblstudentinfo);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.txtdashboardstudentgpa);
            this.Controls.Add(this.txtdashboardstudentname);
            this.Controls.Add(this.txtdashboardstudentid);
            this.Controls.Add(this.lblStudentgpa);
            this.Controls.Add(this.lblstudentid);
            this.Controls.Add(this.lblStudentname);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.btnsearchstudent);
            this.Controls.Add(this.txtsearchstudent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "EnrollStudent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EnrollStudent";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtdashboardStudentpassword;
        private Label lbldashboardstudentpassword;
        private TextBox txtdashboardstudentphone;
        private Label lbldashboardstudentphone;
        private TextBox txtdashboardstudentaddress;
        private Label lbldashboardstudentaddress;
        private DateTimePicker dateTimePickerstudent;
        private Label lbldashboardstudentdob;
        private Label lblstudentinfo;
        private Button btnupdate;
        private Button btninsert;
        private TextBox txtdashboardstudentgpa;
        private TextBox txtdashboardstudentname;
        private TextBox txtdashboardstudentid;
        private Label lblStudentgpa;
        private Label lblstudentid;
        private Label lblStudentname;
        private Button btnload;
        private Button btnsearchstudent;
        private TextBox txtsearchstudent;
        private Label label2;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn S_ID;
        private DataGridViewTextBoxColumn S_Name;
        private DataGridViewTextBoxColumn S_DOB;
        private DataGridViewTextBoxColumn S_Address;
        private DataGridViewTextBoxColumn S_Phone;
        private DataGridViewTextBoxColumn S_GPA;
        private Button btnenrollmentback;
    }
}