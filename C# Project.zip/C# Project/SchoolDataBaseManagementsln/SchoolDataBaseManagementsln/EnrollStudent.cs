﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class EnrollStudent : Form
    {
        public EnrollStudent()
        {
            InitializeComponent();
        }
        public void Load()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select * from Student";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView1.Rows[e.RowIndex].Cells["S_ID"].Value.ToString();
            string name = dataGridView1.Rows[e.RowIndex].Cells["S_Name"].Value.ToString();

            string address = dataGridView1.Rows[e.RowIndex].Cells["S_Address"].Value.ToString();
            string phone = dataGridView1.Rows[e.RowIndex].Cells["S_Phone"].Value.ToString();
            string GPA = dataGridView1.Rows[e.RowIndex].Cells["S_GPA"].Value.ToString();

            txtdashboardstudentid.Text = id;
            txtdashboardstudentname.Text = name;
            dateTimePickerstudent.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells["S_DOB"].Value);
            txtdashboardstudentaddress.Text = address;
            txtdashboardstudentphone.Text = phone;
            txtdashboardstudentgpa.Text = GPA;
            txtdashboardStudentpassword.Text = "";
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            Load();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO Student( S_Name, S_Address, S_Phone,S_GPA,S_DOB,S_Pass,S_Jdate) VALUES('" + txtdashboardstudentname.Text + "', '" + txtdashboardstudentaddress.Text + "', '" + txtdashboardstudentphone.Text + "','" + txtdashboardstudentgpa.Text + "','" + dateTimePickerstudent.Value + "','" + txtdashboardStudentpassword.Text + "','"+DateTime.Now +"')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Student set S_Name='" + txtdashboardstudentname.Text + "',S_Address='" + txtdashboardstudentaddress.Text + "',S_Phone='" + txtdashboardstudentphone.Text + "',S_GPA='" + txtdashboardstudentgpa.Text + "',S_DOB='" + dateTimePickerstudent.Value + "',S_Pass='" + txtdashboardStudentpassword.Text + "'where S_ID =" + txtdashboardstudentid.Text;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            Load();
        }

        private void btndashboardstudentback_Click(object sender, EventArgs e)
        {
           
        }

        private void btnenrollmentback_Click(object sender, EventArgs e)
        {
            AccountDashBoard adb = new AccountDashBoard();
            this.Hide();
            adb.Show();
        }

        private void btnsearchstudent_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from Student where S_ID like '" + txtsearchstudent.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void dateTimePickerstudent_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
