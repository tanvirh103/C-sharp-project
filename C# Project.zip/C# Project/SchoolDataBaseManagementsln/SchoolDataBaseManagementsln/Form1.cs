namespace SchoolDataBaseManagementsln
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void linkCreate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            NewAccount n=new NewAccount();
            this.Hide();
            n.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}