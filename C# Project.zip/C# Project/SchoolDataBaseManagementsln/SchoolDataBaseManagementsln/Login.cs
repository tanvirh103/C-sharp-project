﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{

    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            
            SqlCommand cmd;
            
            string user = txtusername.Text;
            string pass = txtpassword.Text;
            string[] role ={"Admin","Teacher","Student","Staff","Accountant"};
            string[] synt ={"A_ID","T_ID", "S_ID", "ST_ID","ACC_ID"};
            string[] synt0 = {"A_Pass","T_Pass", "S_Pass", "ST_Pass","ACC_Pass"};
            cmd = new SqlCommand();
            conn.Open();
            cmd.Connection = conn;
            SqlDataReader dr;
            for (int i = 0; i < 5; i++)
            {
                
                cmd.CommandText = "SELECT * FROM "+role[i]+" Where "+synt[i]+"='" + txtusername.Text + "' AND "+synt0[i]+" ='" + txtpassword.Text + "'";
                //MessageBox.Show(cmd.CommandText);
                dr = cmd.ExecuteReader();
               // int j = 0;
                if (dr.Read())
                {
                    //MessageBox.Show("Login sucess Welcome");
                    if (i == 0)
                    {

                        AdminDashBoard AD = new AdminDashBoard();
                        this.Hide();
                        AD.Show();
                       // j++;

                        break;
                    }
                    else if (i == 1)
                    {
                        TeacherMenu tm = new TeacherMenu(txtusername.Text);
                        this.Hide();
                        tm.Show();
                       // j++;
                        break;
                    }
                    else if (i == 2)
                    {
                        StudentDash studentDash = new StudentDash(txtusername.Text);
                        this.Hide();

                        // studentDash.sid ="txtusername.Text";
                        //string sid = txtusername.Text;
                        studentDash.Show();
                      //  j++;
                        break;
                    }
                    else if (i == 3)
                    {
                        StaffDash SD = new StaffDash(txtusername.Text);
                        this.Hide();
                        SD.Show();
                      //  j++;
                        break;
                        /* MessageBox.Show("ACC");
                         SqlConnection con = new SqlConnection(@"Data Source=Ifaz\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
                         con.Open();
                         string query = "select ST_Position from Staff Where ST_ID=" + txtusername.Text;
                         SqlCommand cmd0 = new SqlCommand(query, con);
                         //MessageBox.Show(cmd0.CommandText);
                        // cmd0.ExecuteNonQuery();
                         SqlDataReader us = cmd0.ExecuteReader();

                         String pos = us["ST_Position"].ToString();
                         MessageBox.Show(pos);
                         if (pos== "Accountant")
                         { 
                             AccountDashBoard ACD = new AccountDashBoard();
                             this.Hide();
                             ACD.Show();
                             break; 
                         }*/
                    }
                    else if (i == 4)
                    {
                        AccountDashBoard ACD = new AccountDashBoard();
                        this.Hide();
                        ACD.Show();
                       // j++;
                        break;
                    }

                }
                else
                {
                   /* if (j == 0) 
                    { 
                        MessageBox.Show("Incorrect User ID or Password");
                        break;
                    }*/
                }

                 dr.Close();
                

            }

            //if (dr.HasRows) { MessageBox.Show("INCORRECT ENTRY!"); }



        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            NewAccount na=new NewAccount();
            this.Close();
            na.Show();
        }
    }
}