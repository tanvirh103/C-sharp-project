﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class NewAccount : Form
    {
        public NewAccount()
        {
            InitializeComponent();
        }

        private void btnsignup_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO AC_REQ( FirstName, LastName, Password,Category,DOB,Gender) VALUES('" + txtfirstname.Text + "', '" + txtlastname.Text + "', '" + txtpassword.Text + "','" + comboBox2.Text + "','" + dateTimePicker1.Value + "','" + comboBox1.Text + "')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            txtfirstname.Text = " ";
            txtlastname.Text = " ";
            txtpassword.Text = " "; 
            
            comboBox1.Text = " ";
            comboBox2.Text= " ";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f= new Form1();
            this.Close();
            f.Show();
        }
    }
}
