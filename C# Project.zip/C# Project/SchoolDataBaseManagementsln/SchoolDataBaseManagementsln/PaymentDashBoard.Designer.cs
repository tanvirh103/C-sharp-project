﻿namespace SchoolDataBaseManagementsln
{
    partial class PaymentDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PaymentDashBoard));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.TR_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TR_S_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TR_ST_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TR_Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TR_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TR_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblpaymentdashboardStudent = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpaymentdashboardstudentid = new System.Windows.Forms.TextBox();
            this.btnpaymentdashboardsearch = new System.Windows.Forms.Button();
            this.txtpaymentdashboardstudentname = new System.Windows.Forms.TextBox();
            this.txtpaymentdashboardstaffid = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblpaymentdashboardStudentid = new System.Windows.Forms.Label();
            this.lblpaymentdashboardamount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnpaymentdashboardload = new System.Windows.Forms.Button();
            this.btnpaymentdashboardinsert = new System.Windows.Forms.Button();
            this.btnpaymentdashboardupdate = new System.Windows.Forms.Button();
            this.btnpaymentdashboardback = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TR_ID,
            this.TR_S_ID,
            this.TR_ST_ID,
            this.TR_Amount,
            this.TR_Type,
            this.TR_Date});
            this.dataGridView1.Location = new System.Drawing.Point(8, 80);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(458, 212);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // TR_ID
            // 
            this.TR_ID.DataPropertyName = "TR_ID";
            this.TR_ID.HeaderText = "Payment ID";
            this.TR_ID.MinimumWidth = 8;
            this.TR_ID.Name = "TR_ID";
            this.TR_ID.ReadOnly = true;
            this.TR_ID.Width = 150;
            // 
            // TR_S_ID
            // 
            this.TR_S_ID.DataPropertyName = "TR_S_ID";
            this.TR_S_ID.HeaderText = "Student ID";
            this.TR_S_ID.MinimumWidth = 8;
            this.TR_S_ID.Name = "TR_S_ID";
            this.TR_S_ID.ReadOnly = true;
            this.TR_S_ID.Width = 150;
            // 
            // TR_ST_ID
            // 
            this.TR_ST_ID.DataPropertyName = "TR_ST_ID";
            this.TR_ST_ID.HeaderText = "Staff ID";
            this.TR_ST_ID.MinimumWidth = 8;
            this.TR_ST_ID.Name = "TR_ST_ID";
            this.TR_ST_ID.ReadOnly = true;
            this.TR_ST_ID.Width = 150;
            // 
            // TR_Amount
            // 
            this.TR_Amount.DataPropertyName = "TR_Amount";
            this.TR_Amount.HeaderText = "Amount";
            this.TR_Amount.MinimumWidth = 8;
            this.TR_Amount.Name = "TR_Amount";
            this.TR_Amount.ReadOnly = true;
            this.TR_Amount.Width = 150;
            // 
            // TR_Type
            // 
            this.TR_Type.DataPropertyName = "TR_Type";
            this.TR_Type.HeaderText = "Payment Type";
            this.TR_Type.MinimumWidth = 8;
            this.TR_Type.Name = "TR_Type";
            this.TR_Type.ReadOnly = true;
            this.TR_Type.Width = 150;
            // 
            // TR_Date
            // 
            this.TR_Date.DataPropertyName = "TR_Date";
            this.TR_Date.HeaderText = "Payment Date";
            this.TR_Date.MinimumWidth = 8;
            this.TR_Date.Name = "TR_Date";
            this.TR_Date.ReadOnly = true;
            this.TR_Date.Width = 150;
            // 
            // lblpaymentdashboardStudent
            // 
            this.lblpaymentdashboardStudent.AutoSize = true;
            this.lblpaymentdashboardStudent.BackColor = System.Drawing.Color.Transparent;
            this.lblpaymentdashboardStudent.Location = new System.Drawing.Point(470, 82);
            this.lblpaymentdashboardStudent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblpaymentdashboardStudent.Name = "lblpaymentdashboardStudent";
            this.lblpaymentdashboardStudent.Size = new System.Drawing.Size(65, 15);
            this.lblpaymentdashboardStudent.TabIndex = 1;
            this.lblpaymentdashboardStudent.Text = "Student ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(470, 160);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Staff ID:\r\n";
            // 
            // txtpaymentdashboardstudentid
            // 
            this.txtpaymentdashboardstudentid.Location = new System.Drawing.Point(545, 80);
            this.txtpaymentdashboardstudentid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtpaymentdashboardstudentid.Name = "txtpaymentdashboardstudentid";
            this.txtpaymentdashboardstudentid.Size = new System.Drawing.Size(150, 23);
            this.txtpaymentdashboardstudentid.TabIndex = 3;
            // 
            // btnpaymentdashboardsearch
            // 
            this.btnpaymentdashboardsearch.Location = new System.Drawing.Point(732, 80);
            this.btnpaymentdashboardsearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnpaymentdashboardsearch.Name = "btnpaymentdashboardsearch";
            this.btnpaymentdashboardsearch.Size = new System.Drawing.Size(80, 30);
            this.btnpaymentdashboardsearch.TabIndex = 4;
            this.btnpaymentdashboardsearch.Text = "Search";
            this.btnpaymentdashboardsearch.UseVisualStyleBackColor = true;
            this.btnpaymentdashboardsearch.Click += new System.EventHandler(this.btnpaymentdashboardsearch_Click);
            // 
            // txtpaymentdashboardstudentname
            // 
            this.txtpaymentdashboardstudentname.Location = new System.Drawing.Point(565, 115);
            this.txtpaymentdashboardstudentname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtpaymentdashboardstudentname.Name = "txtpaymentdashboardstudentname";
            this.txtpaymentdashboardstudentname.Size = new System.Drawing.Size(130, 23);
            this.txtpaymentdashboardstudentname.TabIndex = 5;
            // 
            // txtpaymentdashboardstaffid
            // 
            this.txtpaymentdashboardstaffid.Location = new System.Drawing.Point(565, 160);
            this.txtpaymentdashboardstaffid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtpaymentdashboardstaffid.Name = "txtpaymentdashboardstaffid";
            this.txtpaymentdashboardstaffid.Size = new System.Drawing.Size(130, 23);
            this.txtpaymentdashboardstaffid.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(565, 197);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(130, 23);
            this.textBox3.TabIndex = 7;
            // 
            // lblpaymentdashboardStudentid
            // 
            this.lblpaymentdashboardStudentid.AutoSize = true;
            this.lblpaymentdashboardStudentid.BackColor = System.Drawing.Color.Transparent;
            this.lblpaymentdashboardStudentid.Location = new System.Drawing.Point(470, 117);
            this.lblpaymentdashboardStudentid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblpaymentdashboardStudentid.Name = "lblpaymentdashboardStudentid";
            this.lblpaymentdashboardStudentid.Size = new System.Drawing.Size(65, 15);
            this.lblpaymentdashboardStudentid.TabIndex = 9;
            this.lblpaymentdashboardStudentid.Text = "Student ID:";
            // 
            // lblpaymentdashboardamount
            // 
            this.lblpaymentdashboardamount.AutoSize = true;
            this.lblpaymentdashboardamount.BackColor = System.Drawing.Color.Transparent;
            this.lblpaymentdashboardamount.Location = new System.Drawing.Point(470, 197);
            this.lblpaymentdashboardamount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblpaymentdashboardamount.Name = "lblpaymentdashboardamount";
            this.lblpaymentdashboardamount.Size = new System.Drawing.Size(54, 15);
            this.lblpaymentdashboardamount.TabIndex = 10;
            this.lblpaymentdashboardamount.Text = "Amount:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(286, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 32);
            this.label1.TabIndex = 13;
            this.label1.Text = "Payment Information";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnpaymentdashboardload
            // 
            this.btnpaymentdashboardload.Location = new System.Drawing.Point(162, 323);
            this.btnpaymentdashboardload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnpaymentdashboardload.Name = "btnpaymentdashboardload";
            this.btnpaymentdashboardload.Size = new System.Drawing.Size(80, 30);
            this.btnpaymentdashboardload.TabIndex = 14;
            this.btnpaymentdashboardload.Text = "Load";
            this.btnpaymentdashboardload.UseVisualStyleBackColor = true;
            this.btnpaymentdashboardload.Click += new System.EventHandler(this.btnpaymentdashboardload_Click);
            // 
            // btnpaymentdashboardinsert
            // 
            this.btnpaymentdashboardinsert.Location = new System.Drawing.Point(518, 308);
            this.btnpaymentdashboardinsert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnpaymentdashboardinsert.Name = "btnpaymentdashboardinsert";
            this.btnpaymentdashboardinsert.Size = new System.Drawing.Size(80, 30);
            this.btnpaymentdashboardinsert.TabIndex = 15;
            this.btnpaymentdashboardinsert.Text = "Insert";
            this.btnpaymentdashboardinsert.UseVisualStyleBackColor = true;
            this.btnpaymentdashboardinsert.Click += new System.EventHandler(this.btnpaymentdashboardinsert_Click);
            // 
            // btnpaymentdashboardupdate
            // 
            this.btnpaymentdashboardupdate.Location = new System.Drawing.Point(663, 308);
            this.btnpaymentdashboardupdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnpaymentdashboardupdate.Name = "btnpaymentdashboardupdate";
            this.btnpaymentdashboardupdate.Size = new System.Drawing.Size(80, 30);
            this.btnpaymentdashboardupdate.TabIndex = 16;
            this.btnpaymentdashboardupdate.Text = "Update";
            this.btnpaymentdashboardupdate.UseVisualStyleBackColor = true;
            this.btnpaymentdashboardupdate.Click += new System.EventHandler(this.btnpaymentdashboardupdate_Click);
            // 
            // btnpaymentdashboardback
            // 
            this.btnpaymentdashboardback.Location = new System.Drawing.Point(46, 431);
            this.btnpaymentdashboardback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnpaymentdashboardback.Name = "btnpaymentdashboardback";
            this.btnpaymentdashboardback.Size = new System.Drawing.Size(80, 30);
            this.btnpaymentdashboardback.TabIndex = 17;
            this.btnpaymentdashboardback.Text = "Back";
            this.btnpaymentdashboardback.UseVisualStyleBackColor = true;
            this.btnpaymentdashboardback.Click += new System.EventHandler(this.btnpaymentdashboardback_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(470, 244);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 15);
            this.label3.TabIndex = 18;
            this.label3.Text = "Payment Type:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Tution",
            "Enrollment",
            "Fine",
            "Due",
            "Re-Addmission"});
            this.comboBox1.Location = new System.Drawing.Point(565, 244);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(129, 23);
            this.comboBox1.TabIndex = 19;
            // 
            // PaymentDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnpaymentdashboardback);
            this.Controls.Add(this.btnpaymentdashboardupdate);
            this.Controls.Add(this.btnpaymentdashboardinsert);
            this.Controls.Add(this.btnpaymentdashboardload);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblpaymentdashboardamount);
            this.Controls.Add(this.lblpaymentdashboardStudentid);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txtpaymentdashboardstaffid);
            this.Controls.Add(this.txtpaymentdashboardstudentname);
            this.Controls.Add(this.btnpaymentdashboardsearch);
            this.Controls.Add(this.txtpaymentdashboardstudentid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblpaymentdashboardStudent);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "PaymentDashBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PaymentDashBoard";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Label lblpaymentdashboardStudent;
        private Label label2;
        private TextBox txtpaymentdashboardstudentid;
        private Button btnpaymentdashboardsearch;
        private TextBox txtpaymentdashboardstudentname;
        private TextBox txtpaymentdashboardstaffid;
        private TextBox textBox3;
        private Label lblpaymentdashboardStudentid;
        private Label lblpaymentdashboardamount;
        private Label label1;
        private Button btnpaymentdashboardload;
        private Button btnpaymentdashboardinsert;
        private Button btnpaymentdashboardupdate;
        private Button btnpaymentdashboardback;
        private Label label3;
        private ComboBox comboBox1;
        private DataGridViewTextBoxColumn TR_ID;
        private DataGridViewTextBoxColumn TR_S_ID;
        private DataGridViewTextBoxColumn TR_ST_ID;
        private DataGridViewTextBoxColumn TR_Amount;
        private DataGridViewTextBoxColumn TR_Type;
        private DataGridViewTextBoxColumn TR_Date;
    }
}