﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SchoolDataBaseManagementsln
{
    public partial class PaymentDashBoard : Form
    {
        public PaymentDashBoard()
        {
            InitializeComponent();
        }
        public void Load() {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select * from TR";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnpaymentdashboardback_Click(object sender, EventArgs e)
        {
            AccountDashBoard ad=new AccountDashBoard();
            this.Hide();
            ad.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnpaymentdashboardload_Click(object sender, EventArgs e)
        {
            Load();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            
            string s_id = dataGridView1.Rows[e.RowIndex].Cells["TR_S_ID"].Value.ToString();

            string staff = dataGridView1.Rows[e.RowIndex].Cells["TR_ST_ID"].Value.ToString();
            string  amount= dataGridView1.Rows[e.RowIndex].Cells["TR_Amount"].Value.ToString();
            string type = dataGridView1.Rows[e.RowIndex].Cells["TR_Type"].Value.ToString();

            txtpaymentdashboardstudentname.Text = s_id;
            txtpaymentdashboardstaffid.Text = staff;
            
            textBox3.Text = amount;
            comboBox1.Text = type;
           
         
        }

        private void btnpaymentdashboardsearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from TR where TR_S_ID like '" + txtpaymentdashboardstudentid.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnpaymentdashboardinsert_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO TR( TR_S_ID, TR_ST_ID, TR_Amount,TR_Type,TR_Date) VALUES('" + txtpaymentdashboardstudentname.Text + "', '" + txtpaymentdashboardstaffid.Text + "', '" + textBox3.Text + "','" + comboBox1.Text + "','" + DateTime.Now + "')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnpaymentdashboardupdate_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Tr set TR_ST_ID='" + txtpaymentdashboardstaffid.Text + "',TR_Amount='" + textBox3.Text + "',TR_Type='" + comboBox1.Text +  "',TR_Date='" + DateTime.Now + "'where TR_S_ID =" + txtpaymentdashboardstudentname.Text;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            Load();
        }
    }
}
