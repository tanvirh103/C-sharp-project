﻿namespace SchoolDataBaseManagementsln
{
    partial class ResultDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResultDash));
            this.lblresultdashinfo = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.S_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_GPA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CL_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CL_Section = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnresultdashload = new System.Windows.Forms.Button();
            this.btnresultdashback = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnresultdashboardsearch = new System.Windows.Forms.Button();
            this.lblresultdashclassid = new System.Windows.Forms.Label();
            this.txtresultclassid = new System.Windows.Forms.TextBox();
            this.btnresultsearchclass = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblresultdashinfo
            // 
            this.lblresultdashinfo.AutoSize = true;
            this.lblresultdashinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblresultdashinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblresultdashinfo.Location = new System.Drawing.Point(348, 41);
            this.lblresultdashinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblresultdashinfo.Name = "lblresultdashinfo";
            this.lblresultdashinfo.Size = new System.Drawing.Size(202, 32);
            this.lblresultdashinfo.TabIndex = 0;
            this.lblresultdashinfo.Text = "Result Information";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.S_ID,
            this.S_Name,
            this.S_GPA,
            this.CL_ID,
            this.CL_Section});
            this.dataGridView1.Location = new System.Drawing.Point(4, 102);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(505, 229);
            this.dataGridView1.TabIndex = 1;
            // 
            // S_ID
            // 
            this.S_ID.DataPropertyName = "S_ID";
            this.S_ID.HeaderText = "Student ID";
            this.S_ID.MinimumWidth = 8;
            this.S_ID.Name = "S_ID";
            this.S_ID.ReadOnly = true;
            this.S_ID.Width = 150;
            // 
            // S_Name
            // 
            this.S_Name.DataPropertyName = "S_Name";
            this.S_Name.HeaderText = "Student Name";
            this.S_Name.MinimumWidth = 8;
            this.S_Name.Name = "S_Name";
            this.S_Name.ReadOnly = true;
            this.S_Name.Width = 150;
            // 
            // S_GPA
            // 
            this.S_GPA.DataPropertyName = "S_GPA";
            this.S_GPA.HeaderText = "Student GPA";
            this.S_GPA.MinimumWidth = 8;
            this.S_GPA.Name = "S_GPA";
            this.S_GPA.ReadOnly = true;
            this.S_GPA.Width = 150;
            // 
            // CL_ID
            // 
            this.CL_ID.DataPropertyName = "CL_ID";
            this.CL_ID.HeaderText = "Class";
            this.CL_ID.MinimumWidth = 8;
            this.CL_ID.Name = "CL_ID";
            this.CL_ID.ReadOnly = true;
            this.CL_ID.Width = 150;
            // 
            // CL_Section
            // 
            this.CL_Section.DataPropertyName = "CL_Section";
            this.CL_Section.HeaderText = "Section";
            this.CL_Section.MinimumWidth = 8;
            this.CL_Section.Name = "CL_Section";
            this.CL_Section.ReadOnly = true;
            this.CL_Section.Width = 150;
            // 
            // btnresultdashload
            // 
            this.btnresultdashload.BackColor = System.Drawing.Color.Transparent;
            this.btnresultdashload.Location = new System.Drawing.Point(229, 362);
            this.btnresultdashload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnresultdashload.Name = "btnresultdashload";
            this.btnresultdashload.Size = new System.Drawing.Size(80, 30);
            this.btnresultdashload.TabIndex = 5;
            this.btnresultdashload.Text = "Load";
            this.btnresultdashload.UseVisualStyleBackColor = false;
            this.btnresultdashload.Click += new System.EventHandler(this.btnresultdashload_Click);
            // 
            // btnresultdashback
            // 
            this.btnresultdashback.BackColor = System.Drawing.Color.Transparent;
            this.btnresultdashback.Location = new System.Drawing.Point(66, 440);
            this.btnresultdashback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnresultdashback.Name = "btnresultdashback";
            this.btnresultdashback.Size = new System.Drawing.Size(80, 30);
            this.btnresultdashback.TabIndex = 7;
            this.btnresultdashback.Text = "Back";
            this.btnresultdashback.UseVisualStyleBackColor = false;
            this.btnresultdashback.Click += new System.EventHandler(this.btnresultdashback_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(512, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Student ID:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(592, 104);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(150, 23);
            this.textBox1.TabIndex = 9;
            // 
            // btnresultdashboardsearch
            // 
            this.btnresultdashboardsearch.Location = new System.Drawing.Point(772, 99);
            this.btnresultdashboardsearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnresultdashboardsearch.Name = "btnresultdashboardsearch";
            this.btnresultdashboardsearch.Size = new System.Drawing.Size(80, 30);
            this.btnresultdashboardsearch.TabIndex = 10;
            this.btnresultdashboardsearch.Text = "Search";
            this.btnresultdashboardsearch.UseVisualStyleBackColor = true;
            this.btnresultdashboardsearch.Click += new System.EventHandler(this.btnresultdashboardsearch_Click);
            // 
            // lblresultdashclassid
            // 
            this.lblresultdashclassid.AutoSize = true;
            this.lblresultdashclassid.BackColor = System.Drawing.Color.Transparent;
            this.lblresultdashclassid.Location = new System.Drawing.Point(519, 150);
            this.lblresultdashclassid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblresultdashclassid.Name = "lblresultdashclassid";
            this.lblresultdashclassid.Size = new System.Drawing.Size(51, 15);
            this.lblresultdashclassid.TabIndex = 11;
            this.lblresultdashclassid.Text = "Class ID:";
            // 
            // txtresultclassid
            // 
            this.txtresultclassid.Location = new System.Drawing.Point(592, 150);
            this.txtresultclassid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtresultclassid.Name = "txtresultclassid";
            this.txtresultclassid.Size = new System.Drawing.Size(150, 23);
            this.txtresultclassid.TabIndex = 12;
            // 
            // btnresultsearchclass
            // 
            this.btnresultsearchclass.Location = new System.Drawing.Point(772, 145);
            this.btnresultsearchclass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnresultsearchclass.Name = "btnresultsearchclass";
            this.btnresultsearchclass.Size = new System.Drawing.Size(80, 30);
            this.btnresultsearchclass.TabIndex = 13;
            this.btnresultsearchclass.Text = "Search";
            this.btnresultsearchclass.UseVisualStyleBackColor = true;
            this.btnresultsearchclass.Click += new System.EventHandler(this.btnresultsearchclass_Click);
            // 
            // ResultDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.btnresultsearchclass);
            this.Controls.Add(this.txtresultclassid);
            this.Controls.Add(this.lblresultdashclassid);
            this.Controls.Add(this.btnresultdashboardsearch);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnresultdashback);
            this.Controls.Add(this.btnresultdashload);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblresultdashinfo);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ResultDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ResultDash";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblresultdashinfo;
        private DataGridView dataGridView1;
        private Button btnresultdashload;
        private Button btnresultdashback;
        private Label label1;
        private TextBox textBox1;
        private Button btnresultdashboardsearch;
        private DataGridViewTextBoxColumn S_ID;
        private DataGridViewTextBoxColumn S_Name;
        private DataGridViewTextBoxColumn S_GPA;
        private DataGridViewTextBoxColumn CL_ID;
        private DataGridViewTextBoxColumn CL_Section;
        private Label lblresultdashclassid;
        private TextBox txtresultclassid;
        private Button btnresultsearchclass;
    }
}