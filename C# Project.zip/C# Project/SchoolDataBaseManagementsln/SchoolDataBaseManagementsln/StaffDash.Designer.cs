﻿namespace SchoolDataBaseManagementsln
{
    partial class StaffDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffDash));
            this.lblstaffdashinfo = new System.Windows.Forms.Label();
            this.lblstaffdashid = new System.Windows.Forms.Label();
            this.lblstaffdashname = new System.Windows.Forms.Label();
            this.lblstaffdashphone = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtstaffdashid = new System.Windows.Forms.TextBox();
            this.txtstaffdashdepartment = new System.Windows.Forms.TextBox();
            this.txtstaffdashphone = new System.Windows.Forms.TextBox();
            this.txtstaffdashname = new System.Windows.Forms.TextBox();
            this.btnstaffdashlogout = new System.Windows.Forms.Button();
            this.lblstaffdashdob = new System.Windows.Forms.Label();
            this.txtstaffdashdob = new System.Windows.Forms.TextBox();
            this.txtstaffdashaddress = new System.Windows.Forms.TextBox();
            this.lblstaffdashaddress = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblstaffdashinfo
            // 
            this.lblstaffdashinfo.AutoSize = true;
            this.lblstaffdashinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffdashinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblstaffdashinfo.Location = new System.Drawing.Point(248, 56);
            this.lblstaffdashinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffdashinfo.Name = "lblstaffdashinfo";
            this.lblstaffdashinfo.Size = new System.Drawing.Size(187, 32);
            this.lblstaffdashinfo.TabIndex = 0;
            this.lblstaffdashinfo.Text = "Your Information";
            // 
            // lblstaffdashid
            // 
            this.lblstaffdashid.AutoSize = true;
            this.lblstaffdashid.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffdashid.Location = new System.Drawing.Point(34, 111);
            this.lblstaffdashid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffdashid.Name = "lblstaffdashid";
            this.lblstaffdashid.Size = new System.Drawing.Size(56, 15);
            this.lblstaffdashid.TabIndex = 1;
            this.lblstaffdashid.Text = "Staff\'s ID:";
            // 
            // lblstaffdashname
            // 
            this.lblstaffdashname.AutoSize = true;
            this.lblstaffdashname.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffdashname.Location = new System.Drawing.Point(34, 154);
            this.lblstaffdashname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffdashname.Name = "lblstaffdashname";
            this.lblstaffdashname.Size = new System.Drawing.Size(77, 15);
            this.lblstaffdashname.TabIndex = 2;
            this.lblstaffdashname.Text = "Staff\'s Name:";
            // 
            // lblstaffdashphone
            // 
            this.lblstaffdashphone.AutoSize = true;
            this.lblstaffdashphone.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffdashphone.Location = new System.Drawing.Point(34, 249);
            this.lblstaffdashphone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffdashphone.Name = "lblstaffdashphone";
            this.lblstaffdashphone.Size = new System.Drawing.Size(91, 15);
            this.lblstaffdashphone.TabIndex = 3;
            this.lblstaffdashphone.Text = "Phone Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(34, 338);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Department:";
            // 
            // txtstaffdashid
            // 
            this.txtstaffdashid.Location = new System.Drawing.Point(119, 109);
            this.txtstaffdashid.Margin = new System.Windows.Forms.Padding(2);
            this.txtstaffdashid.Name = "txtstaffdashid";
            this.txtstaffdashid.ReadOnly = true;
            this.txtstaffdashid.Size = new System.Drawing.Size(217, 23);
            this.txtstaffdashid.TabIndex = 5;
            this.txtstaffdashid.TextChanged += new System.EventHandler(this.txtstaffdashid_TextChanged);
            // 
            // txtstaffdashdepartment
            // 
            this.txtstaffdashdepartment.Location = new System.Drawing.Point(119, 337);
            this.txtstaffdashdepartment.Margin = new System.Windows.Forms.Padding(2);
            this.txtstaffdashdepartment.Name = "txtstaffdashdepartment";
            this.txtstaffdashdepartment.ReadOnly = true;
            this.txtstaffdashdepartment.Size = new System.Drawing.Size(217, 23);
            this.txtstaffdashdepartment.TabIndex = 8;
            // 
            // txtstaffdashphone
            // 
            this.txtstaffdashphone.Location = new System.Drawing.Point(119, 247);
            this.txtstaffdashphone.Margin = new System.Windows.Forms.Padding(2);
            this.txtstaffdashphone.Name = "txtstaffdashphone";
            this.txtstaffdashphone.ReadOnly = true;
            this.txtstaffdashphone.Size = new System.Drawing.Size(217, 23);
            this.txtstaffdashphone.TabIndex = 9;
            // 
            // txtstaffdashname
            // 
            this.txtstaffdashname.Location = new System.Drawing.Point(119, 154);
            this.txtstaffdashname.Margin = new System.Windows.Forms.Padding(2);
            this.txtstaffdashname.Name = "txtstaffdashname";
            this.txtstaffdashname.ReadOnly = true;
            this.txtstaffdashname.Size = new System.Drawing.Size(217, 23);
            this.txtstaffdashname.TabIndex = 10;
            // 
            // btnstaffdashlogout
            // 
            this.btnstaffdashlogout.Location = new System.Drawing.Point(750, 65);
            this.btnstaffdashlogout.Margin = new System.Windows.Forms.Padding(2);
            this.btnstaffdashlogout.Name = "btnstaffdashlogout";
            this.btnstaffdashlogout.Size = new System.Drawing.Size(80, 30);
            this.btnstaffdashlogout.TabIndex = 11;
            this.btnstaffdashlogout.Text = "Logout";
            this.btnstaffdashlogout.UseVisualStyleBackColor = true;
            this.btnstaffdashlogout.Click += new System.EventHandler(this.btnstaffdashdone_Click);
            // 
            // lblstaffdashdob
            // 
            this.lblstaffdashdob.AutoSize = true;
            this.lblstaffdashdob.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffdashdob.Location = new System.Drawing.Point(34, 202);
            this.lblstaffdashdob.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffdashdob.Name = "lblstaffdashdob";
            this.lblstaffdashdob.Size = new System.Drawing.Size(78, 15);
            this.lblstaffdashdob.TabIndex = 13;
            this.lblstaffdashdob.Text = "Date Of Birth:";
            this.lblstaffdashdob.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtstaffdashdob
            // 
            this.txtstaffdashdob.Location = new System.Drawing.Point(119, 200);
            this.txtstaffdashdob.Margin = new System.Windows.Forms.Padding(2);
            this.txtstaffdashdob.Name = "txtstaffdashdob";
            this.txtstaffdashdob.ReadOnly = true;
            this.txtstaffdashdob.Size = new System.Drawing.Size(217, 23);
            this.txtstaffdashdob.TabIndex = 14;
            // 
            // txtstaffdashaddress
            // 
            this.txtstaffdashaddress.Location = new System.Drawing.Point(119, 288);
            this.txtstaffdashaddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtstaffdashaddress.Name = "txtstaffdashaddress";
            this.txtstaffdashaddress.ReadOnly = true;
            this.txtstaffdashaddress.Size = new System.Drawing.Size(217, 23);
            this.txtstaffdashaddress.TabIndex = 15;
            // 
            // lblstaffdashaddress
            // 
            this.lblstaffdashaddress.AutoSize = true;
            this.lblstaffdashaddress.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffdashaddress.Location = new System.Drawing.Point(34, 288);
            this.lblstaffdashaddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstaffdashaddress.Name = "lblstaffdashaddress";
            this.lblstaffdashaddress.Size = new System.Drawing.Size(52, 15);
            this.lblstaffdashaddress.TabIndex = 16;
            this.lblstaffdashaddress.Text = "Address:";
            // 
            // StaffDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.lblstaffdashaddress);
            this.Controls.Add(this.txtstaffdashaddress);
            this.Controls.Add(this.txtstaffdashdob);
            this.Controls.Add(this.lblstaffdashdob);
            this.Controls.Add(this.btnstaffdashlogout);
            this.Controls.Add(this.txtstaffdashname);
            this.Controls.Add(this.txtstaffdashphone);
            this.Controls.Add(this.txtstaffdashdepartment);
            this.Controls.Add(this.txtstaffdashid);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblstaffdashphone);
            this.Controls.Add(this.lblstaffdashname);
            this.Controls.Add(this.lblstaffdashid);
            this.Controls.Add(this.lblstaffdashinfo);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "StaffDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StaffDash";
            this.Load += new System.EventHandler(this.StaffDash_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblstaffdashinfo;
        private Label lblstaffdashid;
        private Label lblstaffdashname;
        private Label lblstaffdashphone;
        private Label label5;
        private TextBox txtstaffdashid;
        private TextBox txtstaffdashdepartment;
        private TextBox txtstaffdashphone;
        private TextBox txtstaffdashname;
        private Button btnstaffdashlogout;
        private Label lblstaffdashdob;
        private TextBox txtstaffdashdob;
        private TextBox txtstaffdashaddress;
        private Label lblstaffdashaddress;
    }
}