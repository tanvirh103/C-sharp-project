﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class StaffDash : Form
    {
        public string stid;
        public StaffDash(string stid)
        {
            InitializeComponent();
            this.stid = stid;
            loader();
        }

        private void loader()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select * from Staff where ST_ID= " + stid + "";
            SqlCommand cmd = new SqlCommand(query, conn);
            //  MessageBox.Show(query);
            cmd.ExecuteNonQuery();

            SqlDataReader DR1 = cmd.ExecuteReader();
            if (DR1.Read())
            {
                txtstaffdashid.Text = DR1.GetValue(0).ToString();
                txtstaffdashname.Text = DR1.GetValue(1).ToString();
                txtstaffdashdob.Text = DR1.GetValue(2).ToString();
                txtstaffdashphone.Text = DR1.GetValue(4).ToString();
                txtstaffdashaddress.Text = DR1.GetValue(3).ToString();
                txtstaffdashdepartment.Text = DR1.GetValue(7).ToString();//add salry


            }
            conn.Close();
        }
        private void btnstaffdashdone_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Close();
            lg.Show();
        }

        private void btnstaffdashback_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtstaffdashid_TextChanged(object sender, EventArgs e)
        {

        }

        private void StaffDash_Load(object sender, EventArgs e)
        {

        }
    }
}
