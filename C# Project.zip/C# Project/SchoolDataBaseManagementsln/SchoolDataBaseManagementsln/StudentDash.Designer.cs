﻿namespace SchoolDataBaseManagementsln
{
    partial class StudentDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentDash));
            this.lblStudentinfo = new System.Windows.Forms.Label();
            this.lblstudentinfoid = new System.Windows.Forms.Label();
            this.lblstudentinfoname = new System.Windows.Forms.Label();
            this.lblstudentinfoDob = new System.Windows.Forms.Label();
            this.lblstudentinfophone = new System.Windows.Forms.Label();
            this.lblstudentinforesult = new System.Windows.Forms.Label();
            this.txtstudentinfoid = new System.Windows.Forms.TextBox();
            this.txtstudentinfoname = new System.Windows.Forms.TextBox();
            this.txtstudentdashdob = new System.Windows.Forms.TextBox();
            this.txtstudentdashphone = new System.Windows.Forms.TextBox();
            this.txtstudentdashresult = new System.Windows.Forms.TextBox();
            this.btnstudentdashlogout = new System.Windows.Forms.Button();
            this.lblstudentdashaddress = new System.Windows.Forms.Label();
            this.txtstudentdashaddress = new System.Windows.Forms.TextBox();
            this.txtstudentdashteacher = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblStudentinfo
            // 
            this.lblStudentinfo.AutoSize = true;
            this.lblStudentinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblStudentinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblStudentinfo.Location = new System.Drawing.Point(328, 44);
            this.lblStudentinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStudentinfo.Name = "lblStudentinfo";
            this.lblStudentinfo.Size = new System.Drawing.Size(187, 32);
            this.lblStudentinfo.TabIndex = 0;
            this.lblStudentinfo.Text = "Your Information";
            // 
            // lblstudentinfoid
            // 
            this.lblstudentinfoid.AutoSize = true;
            this.lblstudentinfoid.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentinfoid.Location = new System.Drawing.Point(54, 119);
            this.lblstudentinfoid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentinfoid.Name = "lblstudentinfoid";
            this.lblstudentinfoid.Size = new System.Drawing.Size(65, 15);
            this.lblstudentinfoid.TabIndex = 1;
            this.lblstudentinfoid.Text = "Student ID:";
            // 
            // lblstudentinfoname
            // 
            this.lblstudentinfoname.AutoSize = true;
            this.lblstudentinfoname.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentinfoname.Location = new System.Drawing.Point(54, 158);
            this.lblstudentinfoname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentinfoname.Name = "lblstudentinfoname";
            this.lblstudentinfoname.Size = new System.Drawing.Size(86, 15);
            this.lblstudentinfoname.TabIndex = 2;
            this.lblstudentinfoname.Text = "Student Name:";
            // 
            // lblstudentinfoDob
            // 
            this.lblstudentinfoDob.AutoSize = true;
            this.lblstudentinfoDob.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentinfoDob.Location = new System.Drawing.Point(54, 196);
            this.lblstudentinfoDob.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentinfoDob.Name = "lblstudentinfoDob";
            this.lblstudentinfoDob.Size = new System.Drawing.Size(76, 15);
            this.lblstudentinfoDob.TabIndex = 3;
            this.lblstudentinfoDob.Text = "Date of Birth:";
            // 
            // lblstudentinfophone
            // 
            this.lblstudentinfophone.AutoSize = true;
            this.lblstudentinfophone.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentinfophone.Location = new System.Drawing.Point(54, 282);
            this.lblstudentinfophone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentinfophone.Name = "lblstudentinfophone";
            this.lblstudentinfophone.Size = new System.Drawing.Size(91, 15);
            this.lblstudentinfophone.TabIndex = 4;
            this.lblstudentinfophone.Text = "Phone Number:";
            // 
            // lblstudentinforesult
            // 
            this.lblstudentinforesult.AutoSize = true;
            this.lblstudentinforesult.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentinforesult.Location = new System.Drawing.Point(54, 371);
            this.lblstudentinforesult.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentinforesult.Name = "lblstudentinforesult";
            this.lblstudentinforesult.Size = new System.Drawing.Size(42, 15);
            this.lblstudentinforesult.TabIndex = 5;
            this.lblstudentinforesult.Text = "Result:";
            // 
            // txtstudentinfoid
            // 
            this.txtstudentinfoid.Location = new System.Drawing.Point(149, 119);
            this.txtstudentinfoid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentinfoid.Name = "txtstudentinfoid";
            this.txtstudentinfoid.ReadOnly = true;
            this.txtstudentinfoid.Size = new System.Drawing.Size(200, 23);
            this.txtstudentinfoid.TabIndex = 6;
            // 
            // txtstudentinfoname
            // 
            this.txtstudentinfoname.Location = new System.Drawing.Point(149, 158);
            this.txtstudentinfoname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentinfoname.Name = "txtstudentinfoname";
            this.txtstudentinfoname.ReadOnly = true;
            this.txtstudentinfoname.Size = new System.Drawing.Size(200, 23);
            this.txtstudentinfoname.TabIndex = 7;
            // 
            // txtstudentdashdob
            // 
            this.txtstudentdashdob.Location = new System.Drawing.Point(149, 196);
            this.txtstudentdashdob.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentdashdob.Name = "txtstudentdashdob";
            this.txtstudentdashdob.ReadOnly = true;
            this.txtstudentdashdob.Size = new System.Drawing.Size(200, 23);
            this.txtstudentdashdob.TabIndex = 8;
            // 
            // txtstudentdashphone
            // 
            this.txtstudentdashphone.Location = new System.Drawing.Point(149, 280);
            this.txtstudentdashphone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentdashphone.Name = "txtstudentdashphone";
            this.txtstudentdashphone.ReadOnly = true;
            this.txtstudentdashphone.Size = new System.Drawing.Size(200, 23);
            this.txtstudentdashphone.TabIndex = 9;
            this.txtstudentdashphone.TextChanged += new System.EventHandler(this.txtstudentdashphone_TextChanged);
            // 
            // txtstudentdashresult
            // 
            this.txtstudentdashresult.Location = new System.Drawing.Point(149, 370);
            this.txtstudentdashresult.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentdashresult.Name = "txtstudentdashresult";
            this.txtstudentdashresult.ReadOnly = true;
            this.txtstudentdashresult.Size = new System.Drawing.Size(200, 23);
            this.txtstudentdashresult.TabIndex = 10;
            // 
            // btnstudentdashlogout
            // 
            this.btnstudentdashlogout.Location = new System.Drawing.Point(785, 52);
            this.btnstudentdashlogout.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnstudentdashlogout.Name = "btnstudentdashlogout";
            this.btnstudentdashlogout.Size = new System.Drawing.Size(80, 30);
            this.btnstudentdashlogout.TabIndex = 11;
            this.btnstudentdashlogout.Text = "Logout";
            this.btnstudentdashlogout.UseVisualStyleBackColor = true;
            this.btnstudentdashlogout.Click += new System.EventHandler(this.btnstudentdashdone_Click);
            // 
            // lblstudentdashaddress
            // 
            this.lblstudentdashaddress.AutoSize = true;
            this.lblstudentdashaddress.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentdashaddress.Location = new System.Drawing.Point(54, 239);
            this.lblstudentdashaddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentdashaddress.Name = "lblstudentdashaddress";
            this.lblstudentdashaddress.Size = new System.Drawing.Size(52, 15);
            this.lblstudentdashaddress.TabIndex = 13;
            this.lblstudentdashaddress.Text = "Address:";
            // 
            // txtstudentdashaddress
            // 
            this.txtstudentdashaddress.Location = new System.Drawing.Point(149, 238);
            this.txtstudentdashaddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentdashaddress.Name = "txtstudentdashaddress";
            this.txtstudentdashaddress.ReadOnly = true;
            this.txtstudentdashaddress.Size = new System.Drawing.Size(200, 23);
            this.txtstudentdashaddress.TabIndex = 14;
            // 
            // txtstudentdashteacher
            // 
            this.txtstudentdashteacher.Location = new System.Drawing.Point(149, 326);
            this.txtstudentdashteacher.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentdashteacher.Name = "txtstudentdashteacher";
            this.txtstudentdashteacher.ReadOnly = true;
            this.txtstudentdashteacher.Size = new System.Drawing.Size(200, 23);
            this.txtstudentdashteacher.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(54, 328);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "Guide Teacher:";
            // 
            // StudentDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtstudentdashteacher);
            this.Controls.Add(this.txtstudentdashaddress);
            this.Controls.Add(this.lblstudentdashaddress);
            this.Controls.Add(this.btnstudentdashlogout);
            this.Controls.Add(this.txtstudentdashresult);
            this.Controls.Add(this.txtstudentdashphone);
            this.Controls.Add(this.txtstudentdashdob);
            this.Controls.Add(this.txtstudentinfoname);
            this.Controls.Add(this.txtstudentinfoid);
            this.Controls.Add(this.lblstudentinforesult);
            this.Controls.Add(this.lblstudentinfophone);
            this.Controls.Add(this.lblstudentinfoDob);
            this.Controls.Add(this.lblstudentinfoname);
            this.Controls.Add(this.lblstudentinfoid);
            this.Controls.Add(this.lblStudentinfo);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "StudentDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentDash";
            this.Load += new System.EventHandler(this.StudentDash_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblStudentinfo;
        private Label lblstudentinfoid;
        private Label lblstudentinfoname;
        private Label lblstudentinfoDob;
        private Label lblstudentinfophone;
        private Label lblstudentinforesult;
        private TextBox txtstudentinfoid;
        private TextBox txtstudentinfoname;
        private TextBox txtstudentdashdob;
        private TextBox txtstudentdashphone;
        private TextBox txtstudentdashresult;
        private Button btnstudentdashlogout;
        private Label lblstudentdashaddress;
        private TextBox txtstudentdashaddress;
        private TextBox txtstudentdashteacher;
        private Label label1;
    }
}