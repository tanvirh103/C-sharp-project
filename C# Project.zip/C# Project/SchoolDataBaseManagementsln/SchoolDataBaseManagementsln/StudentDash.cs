﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SchoolDataBaseManagementsln
{
    public partial class StudentDash : Form
    {
        public String sid;
        public StudentDash(String s_id)
        { sid = s_id;
            InitializeComponent();
            loader();


        }

        private void loader()
        {
        SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
        conn.Open();
        string query = "select * from Student where S_ID= "+sid+"";
        SqlCommand cmd = new SqlCommand(query, conn);
          //  MessageBox.Show(query);
        cmd.ExecuteNonQuery();

            SqlDataReader DR1 = cmd.ExecuteReader();
            if (DR1.Read())
            {
                txtstudentinfoid.Text = DR1.GetValue(0).ToString();
                txtstudentinfoname.Text = DR1.GetValue(1).ToString();
                txtstudentdashdob.Text = DR1.GetValue(2).ToString();
                txtstudentdashaddress.Text = DR1.GetValue(3).ToString();
                txtstudentdashphone.Text = DR1.GetValue(4).ToString();
                txtstudentdashresult.Text = DR1.GetValue(5).ToString();
                txtstudentdashteacher.Text = DR1.GetValue(7).ToString();

            }
            conn.Close();
        }


      /* SqlConnection Conn = new SqlConnection(Connection_String);
        SqlCommand Comm1 = new SqlCommand(Command, Conn);
        Conn.Open();*/
       
        private void btnstudentdashdone_Click(object sender, EventArgs e)
        {
            Login lg=new Login();
            this.Close();
            lg.Show();
        }

        private void btnstudentdashback_Click(object sender, EventArgs e)
        {
        }

        private void StudentDash_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

        }

        private void txtstudentdashphone_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
