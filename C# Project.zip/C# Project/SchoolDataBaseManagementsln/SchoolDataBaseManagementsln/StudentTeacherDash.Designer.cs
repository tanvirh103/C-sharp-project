﻿namespace SchoolDataBaseManagementsln
{
    partial class StudentTeacherDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentTeacherDash));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.S_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_GPA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblstudentteacherdashinfo = new System.Windows.Forms.Label();
            this.lblstudentteacherdashid = new System.Windows.Forms.Label();
            this.lblstudentteacherdashresult = new System.Windows.Forms.Label();
            this.txtstudentteacherdashid = new System.Windows.Forms.TextBox();
            this.txtstudentteacherdashresult = new System.Windows.Forms.TextBox();
            this.btnstudentteachersearch = new System.Windows.Forms.Button();
            this.btnstudentteacherdashupdate = new System.Windows.Forms.Button();
            this.btnstudentteacherdashback = new System.Windows.Forms.Button();
            this.lblstudentteacherdashname = new System.Windows.Forms.Label();
            this.txtstudentteacherdashname = new System.Windows.Forms.TextBox();
            this.btnstudentteacherdashboardload = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.S_ID,
            this.S_Name,
            this.T_Name,
            this.S_DOB,
            this.S_Address,
            this.S_Phone,
            this.S_GPA});
            this.dataGridView1.Location = new System.Drawing.Point(8, 84);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(514, 199);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // S_ID
            // 
            this.S_ID.DataPropertyName = "S_ID";
            this.S_ID.HeaderText = "Student ID";
            this.S_ID.MinimumWidth = 8;
            this.S_ID.Name = "S_ID";
            this.S_ID.ReadOnly = true;
            this.S_ID.Width = 150;
            // 
            // S_Name
            // 
            this.S_Name.DataPropertyName = "S_Name";
            this.S_Name.HeaderText = "Student Name";
            this.S_Name.MinimumWidth = 8;
            this.S_Name.Name = "S_Name";
            this.S_Name.ReadOnly = true;
            this.S_Name.Width = 150;
            // 
            // T_Name
            // 
            this.T_Name.DataPropertyName = "T_Name";
            this.T_Name.HeaderText = "Guide Teacher";
            this.T_Name.MinimumWidth = 8;
            this.T_Name.Name = "T_Name";
            this.T_Name.ReadOnly = true;
            this.T_Name.Width = 150;
            // 
            // S_DOB
            // 
            this.S_DOB.DataPropertyName = "S_DOB";
            this.S_DOB.HeaderText = "Student DOB";
            this.S_DOB.MinimumWidth = 8;
            this.S_DOB.Name = "S_DOB";
            this.S_DOB.ReadOnly = true;
            this.S_DOB.Width = 150;
            // 
            // S_Address
            // 
            this.S_Address.DataPropertyName = "S_Address";
            this.S_Address.HeaderText = "Student Address";
            this.S_Address.MinimumWidth = 8;
            this.S_Address.Name = "S_Address";
            this.S_Address.ReadOnly = true;
            this.S_Address.Width = 150;
            // 
            // S_Phone
            // 
            this.S_Phone.DataPropertyName = "S_Phone";
            this.S_Phone.HeaderText = "Student Phone";
            this.S_Phone.MinimumWidth = 8;
            this.S_Phone.Name = "S_Phone";
            this.S_Phone.ReadOnly = true;
            this.S_Phone.Width = 150;
            // 
            // S_GPA
            // 
            this.S_GPA.DataPropertyName = "S_GPA";
            this.S_GPA.HeaderText = "Student GPA";
            this.S_GPA.MinimumWidth = 8;
            this.S_GPA.Name = "S_GPA";
            this.S_GPA.ReadOnly = true;
            this.S_GPA.Width = 150;
            // 
            // lblstudentteacherdashinfo
            // 
            this.lblstudentteacherdashinfo.AutoSize = true;
            this.lblstudentteacherdashinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentteacherdashinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblstudentteacherdashinfo.Location = new System.Drawing.Point(257, 26);
            this.lblstudentteacherdashinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentteacherdashinfo.Name = "lblstudentteacherdashinfo";
            this.lblstudentteacherdashinfo.Size = new System.Drawing.Size(220, 32);
            this.lblstudentteacherdashinfo.TabIndex = 1;
            this.lblstudentteacherdashinfo.Text = "Student Information";
            // 
            // lblstudentteacherdashid
            // 
            this.lblstudentteacherdashid.AutoSize = true;
            this.lblstudentteacherdashid.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentteacherdashid.Location = new System.Drawing.Point(538, 86);
            this.lblstudentteacherdashid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentteacherdashid.Name = "lblstudentteacherdashid";
            this.lblstudentteacherdashid.Size = new System.Drawing.Size(65, 15);
            this.lblstudentteacherdashid.TabIndex = 2;
            this.lblstudentteacherdashid.Text = "Student ID:";
            // 
            // lblstudentteacherdashresult
            // 
            this.lblstudentteacherdashresult.AutoSize = true;
            this.lblstudentteacherdashresult.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentteacherdashresult.Location = new System.Drawing.Point(538, 200);
            this.lblstudentteacherdashresult.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentteacherdashresult.Name = "lblstudentteacherdashresult";
            this.lblstudentteacherdashresult.Size = new System.Drawing.Size(42, 15);
            this.lblstudentteacherdashresult.TabIndex = 3;
            this.lblstudentteacherdashresult.Text = "Result:";
            // 
            // txtstudentteacherdashid
            // 
            this.txtstudentteacherdashid.Location = new System.Drawing.Point(622, 84);
            this.txtstudentteacherdashid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentteacherdashid.Name = "txtstudentteacherdashid";
            this.txtstudentteacherdashid.Size = new System.Drawing.Size(162, 23);
            this.txtstudentteacherdashid.TabIndex = 4;
            this.txtstudentteacherdashid.TextChanged += new System.EventHandler(this.txtstudentteacherdashid_TextChanged);
            // 
            // txtstudentteacherdashresult
            // 
            this.txtstudentteacherdashresult.Location = new System.Drawing.Point(622, 196);
            this.txtstudentteacherdashresult.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentteacherdashresult.Name = "txtstudentteacherdashresult";
            this.txtstudentteacherdashresult.Size = new System.Drawing.Size(162, 23);
            this.txtstudentteacherdashresult.TabIndex = 5;
            // 
            // btnstudentteachersearch
            // 
            this.btnstudentteachersearch.Location = new System.Drawing.Point(808, 82);
            this.btnstudentteachersearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnstudentteachersearch.Name = "btnstudentteachersearch";
            this.btnstudentteachersearch.Size = new System.Drawing.Size(80, 30);
            this.btnstudentteachersearch.TabIndex = 6;
            this.btnstudentteachersearch.Text = "Search";
            this.btnstudentteachersearch.UseVisualStyleBackColor = true;
            this.btnstudentteachersearch.Click += new System.EventHandler(this.btnstudentteachersearch_Click);
            // 
            // btnstudentteacherdashupdate
            // 
            this.btnstudentteacherdashupdate.Location = new System.Drawing.Point(648, 263);
            this.btnstudentteacherdashupdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnstudentteacherdashupdate.Name = "btnstudentteacherdashupdate";
            this.btnstudentteacherdashupdate.Size = new System.Drawing.Size(80, 30);
            this.btnstudentteacherdashupdate.TabIndex = 7;
            this.btnstudentteacherdashupdate.Text = "Update";
            this.btnstudentteacherdashupdate.UseVisualStyleBackColor = true;
            this.btnstudentteacherdashupdate.Click += new System.EventHandler(this.btnstudentteacherdashupdate_Click);
            // 
            // btnstudentteacherdashback
            // 
            this.btnstudentteacherdashback.Location = new System.Drawing.Point(58, 433);
            this.btnstudentteacherdashback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnstudentteacherdashback.Name = "btnstudentteacherdashback";
            this.btnstudentteacherdashback.Size = new System.Drawing.Size(80, 30);
            this.btnstudentteacherdashback.TabIndex = 8;
            this.btnstudentteacherdashback.Text = "Back";
            this.btnstudentteacherdashback.UseVisualStyleBackColor = true;
            this.btnstudentteacherdashback.Click += new System.EventHandler(this.btnstudentteacherdashback_Click);
            // 
            // lblstudentteacherdashname
            // 
            this.lblstudentteacherdashname.AutoSize = true;
            this.lblstudentteacherdashname.BackColor = System.Drawing.Color.Transparent;
            this.lblstudentteacherdashname.Location = new System.Drawing.Point(527, 158);
            this.lblstudentteacherdashname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstudentteacherdashname.Name = "lblstudentteacherdashname";
            this.lblstudentteacherdashname.Size = new System.Drawing.Size(86, 15);
            this.lblstudentteacherdashname.TabIndex = 9;
            this.lblstudentteacherdashname.Text = "Student Name:";
            // 
            // txtstudentteacherdashname
            // 
            this.txtstudentteacherdashname.Location = new System.Drawing.Point(622, 158);
            this.txtstudentteacherdashname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtstudentteacherdashname.Name = "txtstudentteacherdashname";
            this.txtstudentteacherdashname.ReadOnly = true;
            this.txtstudentteacherdashname.Size = new System.Drawing.Size(162, 23);
            this.txtstudentteacherdashname.TabIndex = 10;
            // 
            // btnstudentteacherdashboardload
            // 
            this.btnstudentteacherdashboardload.Location = new System.Drawing.Point(212, 322);
            this.btnstudentteacherdashboardload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnstudentteacherdashboardload.Name = "btnstudentteacherdashboardload";
            this.btnstudentteacherdashboardload.Size = new System.Drawing.Size(80, 30);
            this.btnstudentteacherdashboardload.TabIndex = 11;
            this.btnstudentteacherdashboardload.Text = "Load";
            this.btnstudentteacherdashboardload.UseVisualStyleBackColor = true;
            this.btnstudentteacherdashboardload.Click += new System.EventHandler(this.btnstudentteacherdashboardload_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(622, 123);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(162, 23);
            this.textBox1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(538, 125);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "Student ID:";
            // 
            // StudentTeacherDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnstudentteacherdashboardload);
            this.Controls.Add(this.txtstudentteacherdashname);
            this.Controls.Add(this.lblstudentteacherdashname);
            this.Controls.Add(this.btnstudentteacherdashback);
            this.Controls.Add(this.btnstudentteacherdashupdate);
            this.Controls.Add(this.btnstudentteachersearch);
            this.Controls.Add(this.txtstudentteacherdashresult);
            this.Controls.Add(this.txtstudentteacherdashid);
            this.Controls.Add(this.lblstudentteacherdashresult);
            this.Controls.Add(this.lblstudentteacherdashid);
            this.Controls.Add(this.lblstudentteacherdashinfo);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "StudentTeacherDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentTeacherDash";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Label lblstudentteacherdashinfo;
        private Label lblstudentteacherdashid;
        private Label lblstudentteacherdashresult;
        private TextBox txtstudentteacherdashid;
        private TextBox txtstudentteacherdashresult;
        private Button btnstudentteachersearch;
        private Button btnstudentteacherdashupdate;
        private Button btnstudentteacherdashback;
        private Label lblstudentteacherdashname;
        private TextBox txtstudentteacherdashname;
        private Button btnstudentteacherdashboardload;
        private TextBox textBox1;
        private Label label1;
        private DataGridViewTextBoxColumn S_ID;
        private DataGridViewTextBoxColumn S_Name;
        private DataGridViewTextBoxColumn T_Name;
        private DataGridViewTextBoxColumn S_DOB;
        private DataGridViewTextBoxColumn S_Address;
        private DataGridViewTextBoxColumn S_Phone;
        private DataGridViewTextBoxColumn S_GPA;
    }
}