﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class StudentTeacherDash : Form
    {
        public string tid;
        public StudentTeacherDash(string tid)
        {
            InitializeComponent();
            this.tid = tid;
        }
        public void Load()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select *,Teacher.T_Name from Student,Teacher where Student.GT_ID=Teacher.T_ID;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void btnstudentteacherdashback_Click(object sender, EventArgs e)
        {
            TeacherMenu tm=new TeacherMenu(tid);
            this.Hide();
            tm.Show();
        }

        private void btnstudentteacherdashboardload_Click(object sender, EventArgs e)
        {
            Load();
        }

        private void txtstudentteacherdashid_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnstudentteachersearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from Student where S_ID like '" + txtstudentteacherdashid.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string name = dataGridView1.Rows[e.RowIndex].Cells["S_Name"].Value.ToString();
            string result = dataGridView1.Rows[e.RowIndex].Cells["S_GPA"].Value.ToString();
            string id = dataGridView1.Rows[e.RowIndex].Cells["S_ID"].Value.ToString();
            txtstudentteacherdashname.Text = name;
            txtstudentteacherdashresult.Text = result;
            textBox1.Text = id;

        }

        private void btnstudentteacherdashupdate_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Student set S_GPA='" + txtstudentteacherdashresult.Text +  "'where S_ID =" + textBox1.Text;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            Load();
        }

        private void StudentTeacherDash_Load(object sender, EventArgs e)
        {

        }
    }
}
