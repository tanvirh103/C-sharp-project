﻿namespace SchoolDataBaseManagementsln
{
    partial class SubjectDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubjectDash));
            this.lblsubjectdashsearch = new System.Windows.Forms.Label();
            this.lblsubjectdashinfo = new System.Windows.Forms.Label();
            this.lblsubjectdashid = new System.Windows.Forms.Label();
            this.lblsubjectdashname = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SUB_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SUB_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SUB_T_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.T_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnsubjectdashsearch = new System.Windows.Forms.Button();
            this.txtsubjectdashid = new System.Windows.Forms.TextBox();
            this.txtsubjectdashname = new System.Windows.Forms.TextBox();
            this.lblsubjectdashteachername = new System.Windows.Forms.Label();
            this.btnsubjectdashupdate = new System.Windows.Forms.Button();
            this.btnsubjectdashback = new System.Windows.Forms.Button();
            this.btnsubjectdashload = new System.Windows.Forms.Button();
            this.lblsubjectdashinsert = new System.Windows.Forms.Button();
            this.lblsujectdashdelete = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblsubjectdashsearch
            // 
            this.lblsubjectdashsearch.AutoSize = true;
            this.lblsubjectdashsearch.BackColor = System.Drawing.Color.Transparent;
            this.lblsubjectdashsearch.Location = new System.Drawing.Point(490, 70);
            this.lblsubjectdashsearch.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsubjectdashsearch.Name = "lblsubjectdashsearch";
            this.lblsubjectdashsearch.Size = new System.Drawing.Size(63, 15);
            this.lblsubjectdashsearch.TabIndex = 0;
            this.lblsubjectdashsearch.Text = "Subject ID:";
            // 
            // lblsubjectdashinfo
            // 
            this.lblsubjectdashinfo.AutoSize = true;
            this.lblsubjectdashinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblsubjectdashinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblsubjectdashinfo.Location = new System.Drawing.Point(315, 14);
            this.lblsubjectdashinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsubjectdashinfo.Name = "lblsubjectdashinfo";
            this.lblsubjectdashinfo.Size = new System.Drawing.Size(216, 32);
            this.lblsubjectdashinfo.TabIndex = 1;
            this.lblsubjectdashinfo.Text = "Subject Information";
            // 
            // lblsubjectdashid
            // 
            this.lblsubjectdashid.AutoSize = true;
            this.lblsubjectdashid.BackColor = System.Drawing.Color.Transparent;
            this.lblsubjectdashid.Location = new System.Drawing.Point(490, 107);
            this.lblsubjectdashid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsubjectdashid.Name = "lblsubjectdashid";
            this.lblsubjectdashid.Size = new System.Drawing.Size(63, 15);
            this.lblsubjectdashid.TabIndex = 2;
            this.lblsubjectdashid.Text = "Subject ID:";
            // 
            // lblsubjectdashname
            // 
            this.lblsubjectdashname.AutoSize = true;
            this.lblsubjectdashname.BackColor = System.Drawing.Color.Transparent;
            this.lblsubjectdashname.Location = new System.Drawing.Point(490, 154);
            this.lblsubjectdashname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsubjectdashname.Name = "lblsubjectdashname";
            this.lblsubjectdashname.Size = new System.Drawing.Size(84, 15);
            this.lblsubjectdashname.TabIndex = 3;
            this.lblsubjectdashname.Text = "Subject Name:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SUB_ID,
            this.SUB_Name,
            this.SUB_T_ID,
            this.T_Name});
            this.dataGridView1.Location = new System.Drawing.Point(8, 67);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(468, 215);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // SUB_ID
            // 
            this.SUB_ID.DataPropertyName = "SUB_ID";
            this.SUB_ID.HeaderText = "Subject ID";
            this.SUB_ID.MinimumWidth = 8;
            this.SUB_ID.Name = "SUB_ID";
            this.SUB_ID.ReadOnly = true;
            this.SUB_ID.Width = 150;
            // 
            // SUB_Name
            // 
            this.SUB_Name.DataPropertyName = "SUB_Name";
            this.SUB_Name.HeaderText = "Subject Name";
            this.SUB_Name.MinimumWidth = 8;
            this.SUB_Name.Name = "SUB_Name";
            this.SUB_Name.ReadOnly = true;
            this.SUB_Name.Width = 150;
            // 
            // SUB_T_ID
            // 
            this.SUB_T_ID.DataPropertyName = "SUB_T_ID";
            this.SUB_T_ID.HeaderText = "Teacher ID";
            this.SUB_T_ID.MinimumWidth = 8;
            this.SUB_T_ID.Name = "SUB_T_ID";
            this.SUB_T_ID.ReadOnly = true;
            this.SUB_T_ID.Width = 150;
            // 
            // T_Name
            // 
            this.T_Name.DataPropertyName = "T_Name";
            this.T_Name.HeaderText = "Teacher Name";
            this.T_Name.MinimumWidth = 8;
            this.T_Name.Name = "T_Name";
            this.T_Name.ReadOnly = true;
            this.T_Name.Width = 150;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(576, 71);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 23);
            this.textBox1.TabIndex = 5;
            // 
            // btnsubjectdashsearch
            // 
            this.btnsubjectdashsearch.Location = new System.Drawing.Point(802, 70);
            this.btnsubjectdashsearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsubjectdashsearch.Name = "btnsubjectdashsearch";
            this.btnsubjectdashsearch.Size = new System.Drawing.Size(80, 30);
            this.btnsubjectdashsearch.TabIndex = 6;
            this.btnsubjectdashsearch.Text = "Search";
            this.btnsubjectdashsearch.UseVisualStyleBackColor = true;
            this.btnsubjectdashsearch.Click += new System.EventHandler(this.btnsubjectdashsearch_Click);
            // 
            // txtsubjectdashid
            // 
            this.txtsubjectdashid.Location = new System.Drawing.Point(576, 107);
            this.txtsubjectdashid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtsubjectdashid.Name = "txtsubjectdashid";
            this.txtsubjectdashid.Size = new System.Drawing.Size(173, 23);
            this.txtsubjectdashid.TabIndex = 7;
            // 
            // txtsubjectdashname
            // 
            this.txtsubjectdashname.Location = new System.Drawing.Point(576, 154);
            this.txtsubjectdashname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtsubjectdashname.Name = "txtsubjectdashname";
            this.txtsubjectdashname.Size = new System.Drawing.Size(173, 23);
            this.txtsubjectdashname.TabIndex = 8;
            // 
            // lblsubjectdashteachername
            // 
            this.lblsubjectdashteachername.AutoSize = true;
            this.lblsubjectdashteachername.BackColor = System.Drawing.Color.Transparent;
            this.lblsubjectdashteachername.Location = new System.Drawing.Point(490, 199);
            this.lblsubjectdashteachername.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsubjectdashteachername.Name = "lblsubjectdashteachername";
            this.lblsubjectdashteachername.Size = new System.Drawing.Size(64, 15);
            this.lblsubjectdashteachername.TabIndex = 9;
            this.lblsubjectdashteachername.Text = "Teacher ID:";
            // 
            // btnsubjectdashupdate
            // 
            this.btnsubjectdashupdate.Location = new System.Drawing.Point(624, 273);
            this.btnsubjectdashupdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsubjectdashupdate.Name = "btnsubjectdashupdate";
            this.btnsubjectdashupdate.Size = new System.Drawing.Size(80, 30);
            this.btnsubjectdashupdate.TabIndex = 11;
            this.btnsubjectdashupdate.Text = "Update";
            this.btnsubjectdashupdate.UseVisualStyleBackColor = true;
            this.btnsubjectdashupdate.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnsubjectdashback
            // 
            this.btnsubjectdashback.Location = new System.Drawing.Point(60, 431);
            this.btnsubjectdashback.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsubjectdashback.Name = "btnsubjectdashback";
            this.btnsubjectdashback.Size = new System.Drawing.Size(80, 30);
            this.btnsubjectdashback.TabIndex = 12;
            this.btnsubjectdashback.Text = "Back";
            this.btnsubjectdashback.UseVisualStyleBackColor = true;
            this.btnsubjectdashback.Click += new System.EventHandler(this.btnsubjectdashback_Click);
            // 
            // btnsubjectdashload
            // 
            this.btnsubjectdashload.Location = new System.Drawing.Point(186, 311);
            this.btnsubjectdashload.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsubjectdashload.Name = "btnsubjectdashload";
            this.btnsubjectdashload.Size = new System.Drawing.Size(80, 30);
            this.btnsubjectdashload.TabIndex = 13;
            this.btnsubjectdashload.Text = "Load";
            this.btnsubjectdashload.UseVisualStyleBackColor = true;
            this.btnsubjectdashload.Click += new System.EventHandler(this.btnsubjectdashload_Click);
            // 
            // lblsubjectdashinsert
            // 
            this.lblsubjectdashinsert.Location = new System.Drawing.Point(500, 273);
            this.lblsubjectdashinsert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lblsubjectdashinsert.Name = "lblsubjectdashinsert";
            this.lblsubjectdashinsert.Size = new System.Drawing.Size(80, 30);
            this.lblsubjectdashinsert.TabIndex = 14;
            this.lblsubjectdashinsert.Text = "Insert";
            this.lblsubjectdashinsert.UseVisualStyleBackColor = true;
            this.lblsubjectdashinsert.Click += new System.EventHandler(this.lblsubjectdashinsert_Click);
            // 
            // lblsujectdashdelete
            // 
            this.lblsujectdashdelete.Location = new System.Drawing.Point(757, 273);
            this.lblsujectdashdelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lblsujectdashdelete.Name = "lblsujectdashdelete";
            this.lblsujectdashdelete.Size = new System.Drawing.Size(80, 30);
            this.lblsujectdashdelete.TabIndex = 15;
            this.lblsujectdashdelete.Text = "Delete";
            this.lblsujectdashdelete.UseVisualStyleBackColor = true;
            this.lblsujectdashdelete.Click += new System.EventHandler(this.lblsujectdashdelete_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(576, 199);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(173, 23);
            this.textBox2.TabIndex = 16;
            // 
            // SubjectDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lblsujectdashdelete);
            this.Controls.Add(this.lblsubjectdashinsert);
            this.Controls.Add(this.btnsubjectdashload);
            this.Controls.Add(this.btnsubjectdashback);
            this.Controls.Add(this.btnsubjectdashupdate);
            this.Controls.Add(this.lblsubjectdashteachername);
            this.Controls.Add(this.txtsubjectdashname);
            this.Controls.Add(this.txtsubjectdashid);
            this.Controls.Add(this.btnsubjectdashsearch);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblsubjectdashname);
            this.Controls.Add(this.lblsubjectdashid);
            this.Controls.Add(this.lblsubjectdashinfo);
            this.Controls.Add(this.lblsubjectdashsearch);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "SubjectDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SubjectDash";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblsubjectdashsearch;
        private Label lblsubjectdashinfo;
        private Label lblsubjectdashid;
        private Label lblsubjectdashname;
        private DataGridView dataGridView1;
        private TextBox textBox1;
        private Button btnsubjectdashsearch;
        private TextBox txtsubjectdashid;
        private TextBox txtsubjectdashname;
        private Label lblsubjectdashteachername;
        private Button btnsubjectdashupdate;
        private Button btnsubjectdashback;
        private Button btnsubjectdashload;
        private DataGridViewTextBoxColumn SUB_ID;
        private DataGridViewTextBoxColumn SUB_Name;
        private DataGridViewTextBoxColumn SUB_T_ID;
        private DataGridViewTextBoxColumn T_Name;
        private Button lblsubjectdashinsert;
        private Button lblsujectdashdelete;
        private TextBox textBox2;
    }
}