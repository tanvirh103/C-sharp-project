﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class SubjectDash : Form
    {
        public SubjectDash()
        {
            InitializeComponent();
        }
        public void load()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select Subject.SUB_ID,Subject.SUB_Name,Subject.SUB_T_ID,Teacher.T_Name from Subject,Teacher  where Subject.SUB_T_ID=Teacher.T_ID";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "update Subject set SUB_Name='" + txtsubjectdashname.Text + "',SUB_T_ID='" + textBox2.Text + "'where SUB_ID ='" + txtsubjectdashid.Text+"'";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            load();
        }

        private void btnsubjectdashback_Click(object sender, EventArgs e)
        {
            AdminDashBoard adb = new AdminDashBoard();
            this.Hide();
            adb.Show();
        }

        private void btnsubjectdashload_Click(object sender, EventArgs e)
        {
            load();
        }

        private void btnsubjectdashsearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string que = "select * from Subject where SUB_ID like '" + textBox1.Text + "%'";
            SqlCommand cmd = new SqlCommand(que, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void lblsubjectdashinsert_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();

            string query1 = "INSERT INTO Subject( SUB_Name, SUB_ID, SUB_T_ID) VALUES('" + txtsubjectdashname.Text + "', '" + txtsubjectdashid.Text + "', '" + textBox2.Text + "')";
            SqlCommand cmd = new SqlCommand(query1, conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            

            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void lblsujectdashdelete_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string qu = "delete from Subject where SUB_ID= '"+ txtsubjectdashid.Text+"'";
            SqlCommand cmd = new SqlCommand(qu, conn);
            cmd.ExecuteNonQuery();
            load();
            txtsubjectdashname.Text = " ";
            txtsubjectdashid.Text = " ";
            textBox2.Text = " ";
            

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView1.Rows[e.RowIndex].Cells["SUB_ID"].Value.ToString();
            string name = dataGridView1.Rows[e.RowIndex].Cells["SUB_Name"].Value.ToString();

            string Tid = dataGridView1.Rows[e.RowIndex].Cells["SUB_T_ID"].Value.ToString();

            txtsubjectdashid.Text = id;
            txtsubjectdashname.Text = name;
            textBox2.Text = Tid;
        }
    }
}
