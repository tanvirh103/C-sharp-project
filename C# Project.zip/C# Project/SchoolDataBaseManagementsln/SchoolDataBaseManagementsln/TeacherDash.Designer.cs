﻿namespace SchoolDataBaseManagementsln
{
    partial class TeacherDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeacherDash));
            this.lblteacherdashinfo = new System.Windows.Forms.Label();
            this.lblteacherdashsubject = new System.Windows.Forms.Label();
            this.lblteacherdashPhone = new System.Windows.Forms.Label();
            this.lblteacherdashDOB = new System.Windows.Forms.Label();
            this.lblteacherdashname = new System.Windows.Forms.Label();
            this.lblteacherdashid = new System.Windows.Forms.Label();
            this.txtteacherdashid = new System.Windows.Forms.TextBox();
            this.txtteacherdashname = new System.Windows.Forms.TextBox();
            this.txtteacherdashdob = new System.Windows.Forms.TextBox();
            this.txtteacherdashphone = new System.Windows.Forms.TextBox();
            this.txtteacherdashsubject = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnteacherdashboardlogout = new System.Windows.Forms.Button();
            this.lblTeacherdashaddress = new System.Windows.Forms.Label();
            this.txtteacherdashaddress = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblteacherdashinfo
            // 
            this.lblteacherdashinfo.AutoSize = true;
            this.lblteacherdashinfo.BackColor = System.Drawing.Color.Transparent;
            this.lblteacherdashinfo.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblteacherdashinfo.Location = new System.Drawing.Point(319, 35);
            this.lblteacherdashinfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblteacherdashinfo.Name = "lblteacherdashinfo";
            this.lblteacherdashinfo.Size = new System.Drawing.Size(186, 32);
            this.lblteacherdashinfo.TabIndex = 0;
            this.lblteacherdashinfo.Text = "Your information";
            this.lblteacherdashinfo.Click += new System.EventHandler(this.lblteacherdashinfo_Click);
            // 
            // lblteacherdashsubject
            // 
            this.lblteacherdashsubject.AutoSize = true;
            this.lblteacherdashsubject.BackColor = System.Drawing.Color.Transparent;
            this.lblteacherdashsubject.Location = new System.Drawing.Point(58, 375);
            this.lblteacherdashsubject.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblteacherdashsubject.Name = "lblteacherdashsubject";
            this.lblteacherdashsubject.Size = new System.Drawing.Size(41, 15);
            this.lblteacherdashsubject.TabIndex = 1;
            this.lblteacherdashsubject.Text = "Salary:";
            // 
            // lblteacherdashPhone
            // 
            this.lblteacherdashPhone.AutoSize = true;
            this.lblteacherdashPhone.BackColor = System.Drawing.Color.Transparent;
            this.lblteacherdashPhone.Location = new System.Drawing.Point(58, 324);
            this.lblteacherdashPhone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblteacherdashPhone.Name = "lblteacherdashPhone";
            this.lblteacherdashPhone.Size = new System.Drawing.Size(91, 15);
            this.lblteacherdashPhone.TabIndex = 2;
            this.lblteacherdashPhone.Text = "Phone Number:";
            // 
            // lblteacherdashDOB
            // 
            this.lblteacherdashDOB.AutoSize = true;
            this.lblteacherdashDOB.BackColor = System.Drawing.Color.Transparent;
            this.lblteacherdashDOB.Location = new System.Drawing.Point(58, 236);
            this.lblteacherdashDOB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblteacherdashDOB.Name = "lblteacherdashDOB";
            this.lblteacherdashDOB.Size = new System.Drawing.Size(78, 15);
            this.lblteacherdashDOB.TabIndex = 3;
            this.lblteacherdashDOB.Text = "Date Of Birth:";
            // 
            // lblteacherdashname
            // 
            this.lblteacherdashname.AutoSize = true;
            this.lblteacherdashname.BackColor = System.Drawing.Color.Transparent;
            this.lblteacherdashname.Location = new System.Drawing.Point(58, 185);
            this.lblteacherdashname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblteacherdashname.Name = "lblteacherdashname";
            this.lblteacherdashname.Size = new System.Drawing.Size(93, 15);
            this.lblteacherdashname.TabIndex = 4;
            this.lblteacherdashname.Text = "Teacher\'s Name:";
            // 
            // lblteacherdashid
            // 
            this.lblteacherdashid.AutoSize = true;
            this.lblteacherdashid.BackColor = System.Drawing.Color.Transparent;
            this.lblteacherdashid.Location = new System.Drawing.Point(58, 132);
            this.lblteacherdashid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblteacherdashid.Name = "lblteacherdashid";
            this.lblteacherdashid.Size = new System.Drawing.Size(72, 15);
            this.lblteacherdashid.TabIndex = 5;
            this.lblteacherdashid.Text = "Teacher\'s ID:";
            // 
            // txtteacherdashid
            // 
            this.txtteacherdashid.Location = new System.Drawing.Point(158, 132);
            this.txtteacherdashid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtteacherdashid.Name = "txtteacherdashid";
            this.txtteacherdashid.ReadOnly = true;
            this.txtteacherdashid.Size = new System.Drawing.Size(174, 23);
            this.txtteacherdashid.TabIndex = 6;
            // 
            // txtteacherdashname
            // 
            this.txtteacherdashname.Location = new System.Drawing.Point(158, 185);
            this.txtteacherdashname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtteacherdashname.Name = "txtteacherdashname";
            this.txtteacherdashname.ReadOnly = true;
            this.txtteacherdashname.Size = new System.Drawing.Size(174, 23);
            this.txtteacherdashname.TabIndex = 7;
            // 
            // txtteacherdashdob
            // 
            this.txtteacherdashdob.Location = new System.Drawing.Point(158, 236);
            this.txtteacherdashdob.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtteacherdashdob.Name = "txtteacherdashdob";
            this.txtteacherdashdob.ReadOnly = true;
            this.txtteacherdashdob.Size = new System.Drawing.Size(174, 23);
            this.txtteacherdashdob.TabIndex = 8;
            // 
            // txtteacherdashphone
            // 
            this.txtteacherdashphone.Location = new System.Drawing.Point(158, 322);
            this.txtteacherdashphone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtteacherdashphone.Name = "txtteacherdashphone";
            this.txtteacherdashphone.ReadOnly = true;
            this.txtteacherdashphone.Size = new System.Drawing.Size(174, 23);
            this.txtteacherdashphone.TabIndex = 9;
            // 
            // txtteacherdashsubject
            // 
            this.txtteacherdashsubject.Location = new System.Drawing.Point(158, 371);
            this.txtteacherdashsubject.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtteacherdashsubject.Name = "txtteacherdashsubject";
            this.txtteacherdashsubject.ReadOnly = true;
            this.txtteacherdashsubject.Size = new System.Drawing.Size(174, 23);
            this.txtteacherdashsubject.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(85, 442);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 30);
            this.button1.TabIndex = 12;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnteacherdashboardlogout
            // 
            this.btnteacherdashboardlogout.Location = new System.Drawing.Point(787, 44);
            this.btnteacherdashboardlogout.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnteacherdashboardlogout.Name = "btnteacherdashboardlogout";
            this.btnteacherdashboardlogout.Size = new System.Drawing.Size(80, 30);
            this.btnteacherdashboardlogout.TabIndex = 13;
            this.btnteacherdashboardlogout.Text = "Logout";
            this.btnteacherdashboardlogout.UseVisualStyleBackColor = true;
            this.btnteacherdashboardlogout.Click += new System.EventHandler(this.btnteacherdashboardlogout_Click);
            // 
            // lblTeacherdashaddress
            // 
            this.lblTeacherdashaddress.AutoSize = true;
            this.lblTeacherdashaddress.BackColor = System.Drawing.Color.Transparent;
            this.lblTeacherdashaddress.Location = new System.Drawing.Point(58, 280);
            this.lblTeacherdashaddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTeacherdashaddress.Name = "lblTeacherdashaddress";
            this.lblTeacherdashaddress.Size = new System.Drawing.Size(52, 15);
            this.lblTeacherdashaddress.TabIndex = 14;
            this.lblTeacherdashaddress.Text = "Address:";
            // 
            // txtteacherdashaddress
            // 
            this.txtteacherdashaddress.Location = new System.Drawing.Point(158, 278);
            this.txtteacherdashaddress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtteacherdashaddress.Name = "txtteacherdashaddress";
            this.txtteacherdashaddress.ReadOnly = true;
            this.txtteacherdashaddress.Size = new System.Drawing.Size(174, 23);
            this.txtteacherdashaddress.TabIndex = 15;
            // 
            // TeacherDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.txtteacherdashaddress);
            this.Controls.Add(this.lblTeacherdashaddress);
            this.Controls.Add(this.btnteacherdashboardlogout);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtteacherdashsubject);
            this.Controls.Add(this.txtteacherdashphone);
            this.Controls.Add(this.txtteacherdashdob);
            this.Controls.Add(this.txtteacherdashname);
            this.Controls.Add(this.txtteacherdashid);
            this.Controls.Add(this.lblteacherdashid);
            this.Controls.Add(this.lblteacherdashname);
            this.Controls.Add(this.lblteacherdashDOB);
            this.Controls.Add(this.lblteacherdashPhone);
            this.Controls.Add(this.lblteacherdashsubject);
            this.Controls.Add(this.lblteacherdashinfo);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "TeacherDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TeacherDash";
            this.Load += new System.EventHandler(this.TeacherDash_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblteacherdashinfo;
        private Label lblteacherdashsubject;
        private Label lblteacherdashPhone;
        private Label lblteacherdashDOB;
        private Label lblteacherdashname;
        private Label lblteacherdashid;
        private TextBox txtteacherdashid;
        private TextBox txtteacherdashname;
        private TextBox txtteacherdashdob;
        private TextBox txtteacherdashphone;
        private TextBox txtteacherdashsubject;
        private Button button1;
        private Button btnteacherdashboardlogout;
        private Label lblTeacherdashaddress;
        private TextBox txtteacherdashaddress;
    }
}