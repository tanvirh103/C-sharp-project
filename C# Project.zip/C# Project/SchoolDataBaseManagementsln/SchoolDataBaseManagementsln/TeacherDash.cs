﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class TeacherDash : Form
    {
        public string tid;
        public TeacherDash(string tid)
        {
            InitializeComponent();
            this.tid = tid;
            loader();
        }

        private void loader()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=Tanvir\SQLEXPRESS;Initial Catalog=SchoolManagementSystem;Integrated Security=True");
            conn.Open();
            string query = "select * from Teacher where T_ID= " + tid + "";
            SqlCommand cmd = new SqlCommand(query, conn);
            //  MessageBox.Show(query);
            cmd.ExecuteNonQuery();

            SqlDataReader DR1 = cmd.ExecuteReader();
            if (DR1.Read())
            {
                txtteacherdashid.Text = DR1.GetValue(0).ToString();
                txtteacherdashname.Text = DR1.GetValue(1).ToString();
                txtteacherdashdob.Text = DR1.GetValue(2).ToString();
                txtteacherdashaddress.Text = DR1.GetValue(3).ToString();
                txtteacherdashphone.Text = DR1.GetValue(4).ToString();
                txtteacherdashsubject.Text = DR1.GetValue(5).ToString();
              

            }
            conn.Close();
        }

        private void lblteacherdashinfo_Click(object sender, EventArgs e)
        {

        }

        private void btnteacherdashdone_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TeacherMenu tm=new TeacherMenu(tid);
            this.Hide();
            tm.Show();
        }

        private void btnteacherdashboardlogout_Click(object sender, EventArgs e)
        {
            Login lg=new Login();
            this.Close();
            lg.Show();
        }

        private void TeacherDash_Load(object sender, EventArgs e)
        {

        }
    }
}
