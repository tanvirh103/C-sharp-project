﻿namespace SchoolDataBaseManagementsln
{
    partial class TeacherMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeacherMenu));
            this.lblTeachermenu = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnteachermenulogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTeachermenu
            // 
            this.lblTeachermenu.AutoSize = true;
            this.lblTeachermenu.BackColor = System.Drawing.Color.Transparent;
            this.lblTeachermenu.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTeachermenu.Location = new System.Drawing.Point(329, 60);
            this.lblTeachermenu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTeachermenu.Name = "lblTeachermenu";
            this.lblTeachermenu.Size = new System.Drawing.Size(241, 32);
            this.lblTeachermenu.TabIndex = 0;
            this.lblTeachermenu.Text = "What you want to see";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(372, 155);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 30);
            this.button1.TabIndex = 1;
            this.button1.Text = "Your Information";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(372, 240);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 30);
            this.button2.TabIndex = 2;
            this.button2.Text = "Student Information";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnteachermenulogout
            // 
            this.btnteachermenulogout.Location = new System.Drawing.Point(780, 71);
            this.btnteachermenulogout.Margin = new System.Windows.Forms.Padding(2);
            this.btnteachermenulogout.Name = "btnteachermenulogout";
            this.btnteachermenulogout.Size = new System.Drawing.Size(80, 30);
            this.btnteachermenulogout.TabIndex = 3;
            this.btnteachermenulogout.Text = "Logout";
            this.btnteachermenulogout.UseVisualStyleBackColor = true;
            this.btnteachermenulogout.Click += new System.EventHandler(this.btnteachermenulogout_Click);
            // 
            // TeacherMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 506);
            this.Controls.Add(this.btnteachermenulogout);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblTeachermenu);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "TeacherMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TeacherMenu";
            this.Load += new System.EventHandler(this.TeacherMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTeachermenu;
        private Button button1;
        private Button button2;
        private Button btnteachermenulogout;
    }
}