﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolDataBaseManagementsln
{
    public partial class TeacherMenu : Form
    {
        public string tID;
        public TeacherMenu(string tid)
        {
            tID = tid;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TeacherDash td=new TeacherDash(tID);
            this.Hide();
            td.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StudentTeacherDash std=new StudentTeacherDash(tID);
            this.Hide();
            std.Show();
        }

        private void btnteachermenulogout_Click(object sender, EventArgs e)
        {
            Login lg = new Login();
            this.Close();
            lg.Show();
        }

        private void TeacherMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
